# Sky Island Adventure 3D

A third-person 3D platformer for Android, built with **Godot 4.3** (free, open source, no paid licence).
Run across floating sky islands, collect coins and diamonds, dodge spikes and sweepers, ride moving
platforms, cross rope bridges and open the treasure chest at the end of each of the **5 levels**.

## Features
- Third-person character with run, jump, double jump, squash/stretch, idle/run/air/celebrate animation
- Floating joystick + JUMP button (multi-touch), swipe the right side of the screen to rotate the camera
- Coins (10 pts) and diamonds (100 pts), 50 coins = extra life
- Moving platforms (3 axes), rope bridges, crumbling tiles, blinking tiles, spikes, spinning sweepers, gaps
- Checkpoints (flag turns green) and a treasure chest at the end of every level
- 5 levels with rising difficulty and different looks (meadow, bridges, ice, sunset ruins, night summit)
- Lives, score, time bonus, 1-3 stars per level, saved high score
- Main menu, Level select, Pause / Resume / Restart, Level Complete and Game Over screens
- Settings: music volume, sound volume, graphics quality (Low/Medium/High), vibration, reset progress
- Original music and sound effects; progress saved locally (offline, no internet permission)
- Android back button pauses; the game auto-pauses when the app goes to the background

## Folder structure
```
SkyIslandAdventure3D/
  project.godot            Godot project settings (Compatibility renderer, landscape)
  export_presets.cfg       Ready-made Android export preset
  scenes/                  main_menu.tscn, game.tscn, player.tscn
  scripts/
    game_state.gd          autoload: save/load, settings, input map
    audio_manager.gd       autoload: music + sound effects
    game.gd                level controller (score, lives, checkpoints, pause, complete)
    level_builder.gd       builds islands/bridges/platforms/hazards from data
    levels_data.gd         THE 5 LEVELS (edit this to change or add levels)
    player.gd, camera_rig.gd, hud.gd, touch_controls.gd, main_menu.gd, ...
  audio/music, audio/sfx   .wav files (replace with your own, same names)
  branding/game_logo.png   IN-GAME logo (menu)            <- replace for your logo
  branding/app_icon/       ANDROID launcher icon files      <- replace for your icon
  build/                   exported APKs
```
All 3D models are generated from simple shapes in code, so there are no model files and the game stays light.

## Run it on a computer
1. Download **Godot 4.3 (standard, not .NET)** from https://godotengine.org/download
2. Godot Project Manager -> **Import** -> pick `project.godot` -> **Run** (F5).
3. Keys: WASD/arrows move, Space jump, Esc pause. (Mouse also emulates touch.)

## Build the APK yourself (Windows / Mac / Linux)
You need: Godot 4.3, **JDK 17**, and the **Android SDK** (all free; no paid account needed).
1. Install JDK 17 (e.g. Temurin) and Android Studio (or just its command-line tools). In the SDK manager install
   *Platform-Tools*, *Build-Tools 34.0.0* and *Platform 34*.
2. Godot: **Editor -> Manage Export Templates -> Download and Install** (4.3.stable).
3. Godot: **Editor -> Editor Settings -> Export -> Android**: set *Android SDK Path* and *Java SDK Path*.
   Create a debug keystore once: `keytool -genkey -v -keystore debug.keystore -alias androiddebugkey -storepass android -keypass android -keyalg RSA -validity 10000` and select it in the same settings page (user `androiddebugkey`, password `android`).
4. **Project -> Export -> Android** (the preset already exists). Click **Export Project**, untick *Export With Debug* for a release build, choose a file name -> Save.
   (For a release build you need a release keystore in the preset's Keystore section; a debug keystore also works for private testing.)

## Change the app icon (before exporting)
The Android launcher icon is **separate from the in-game logo**.
- Replace these files with your own PNGs (keep the names and sizes):
  - `branding/app_icon/icon_192.png` – 192x192 classic icon
  - `branding/app_icon/icon_fg_432.png` – 432x432 adaptive foreground (transparent; keep artwork inside the centre ~288 px)
  - `branding/app_icon/icon_bg_432.png` – 432x432 adaptive background
- In Godot: **Project -> Export -> Android -> Options -> Launcher Icons** shows these three slots; you can also
  browse to any other PNGs there. Then export again.
- The in-game logo is only `branding/game_logo.png` (any size, transparent PNG works best).

## Test the APK on your phone
1. Phone: **Settings -> About phone** -> tap *Build number* 7 times, then **Developer options -> USB debugging** (optional).
2. Easiest: copy `SkyIslandAdventure3D.apk` to the phone (USB, Drive, WhatsApp-to-self) -> tap it -> allow
   "Install unknown apps" for that app -> Install -> Open.
3. Or with USB debugging: `adb install -r SkyIslandAdventure3D.apk`.
4. If the game runs slowly choose **Settings -> Graphics -> Low**.
5. If you want to publish on Google Play you need your own release keystore (never lose it), an `.aab` build
   (needs Gradle build enabled in the export preset) and a Google Play developer account (one-time US$25 fee).

## Game notes
- Score = coins x10 + diamonds x100 + treasure 500 + time bonus + 100 per remaining life.
- Stars: 1 for finishing, +1 for 70% of coins, +1 for all diamonds.
- To edit a level, open `scripts/levels_data.gd` (each level is a simple list of pieces).

## Licences
All code, the logo, app icon, music and sound effects were created for this project and may be used freely.
Godot Engine is MIT licensed. The logo font is Poppins (SIL Open Font License); the in-game UI uses Godot's built-in font.
