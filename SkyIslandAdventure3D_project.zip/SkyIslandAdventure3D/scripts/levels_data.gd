class_name LevelsData
extends RefCounted
## The 5 levels, described as simple data. LevelBuilder turns each list of
## "pieces" into 3D geometry. The route always runs forward (-Z); every piece
## starts where the previous one ended.
##
## Piece types
##   island  {len, w, dx, dy, coins, gems, trees, checkpoint, chest, spikes:[[x,z]], sweepers:[{x,z,len,speed}]}
##   round   {r, dx, dy, coins, gems, trees, checkpoint, chest, spikes}
##   gap     {len, dy, coins}                      empty air (coins float in an arc)
##   bridge  {len, w, safe, crumble, coins}        wooden planks (safe = invisible side walls)
##   stones  {count, gap, r, zig, kind, dy_step, coins}   kind: round | crumble | blink
##   mplat   {axis: z|x|y, len, size:Vector2, travel, speed, coins}   moving platform
##
## Jump budget (see player.gd): single jump clears ~4.5 m, double jump ~7 m.

const THEMES := [
	{ # 1 - Meadow Hop
		"sky_top": Color("3d9bff"), "sky_horizon": Color("d4f1ff"), "ambient": Color("9fb9d6"),
		"fog": Color("d4f1ff"), "sun": Color("fff3d6"),
		"grass": Color("6fd05a"), "dirt": Color("9a6b40"), "rock": Color("8a6c4d"),
		"wood": Color("b9824a"), "plat": Color("ffb02e"), "tile": Color("7fd4ff"),
		"music": "adventure_theme", "night": false,
	},
	{ # 2 - Windy Bridges
		"sky_top": Color("5a8dff"), "sky_horizon": Color("ffe8c4"), "ambient": Color("c4b8a6"),
		"fog": Color("ffe8c4"), "sun": Color("ffe6b8"),
		"grass": Color("9ad14f"), "dirt": Color("8f6a45"), "rock": Color("7d6a58"),
		"wood": Color("c48a50"), "plat": Color("ff7a4a"), "tile": Color("9ee37a"),
		"music": "adventure_theme", "night": false,
	},
	{ # 3 - Frozen Peaks
		"sky_top": Color("78b4ea"), "sky_horizon": Color("eaf6ff"), "ambient": Color("aac4de"),
		"fog": Color("e3f1ff"), "sun": Color("f0f8ff"),
		"grass": Color("f2f8ff"), "dirt": Color("b9d4ec"), "rock": Color("7f95ad"),
		"wood": Color("a58563"), "plat": Color("4fc3f7"), "tile": Color("8fe3ff"),
		"music": "adventure_theme", "night": false,
	},
	{ # 4 - Sunset Ruins
		"sky_top": Color("6a3fa0"), "sky_horizon": Color("ffa25f"), "ambient": Color("c49aa0"),
		"fog": Color("ffb27a"), "sun": Color("ffc58a"),
		"grass": Color("d3b062"), "dirt": Color("a9783f"), "rock": Color("7e4d3d"),
		"wood": Color("8c5a3a"), "plat": Color("ff5e7a"), "tile": Color("ffd166"),
		"music": "summit_theme", "night": false,
	},
	{ # 5 - Starlight Summit
		"sky_top": Color("0a1038"), "sky_horizon": Color("4a3a94"), "ambient": Color("7f86c8"),
		"fog": Color("3a2f80"), "sun": Color("b8c4ff"),
		"grass": Color("4fe0c0"), "dirt": Color("3b3a7a"), "rock": Color("322d63"),
		"wood": Color("7a5a9a"), "plat": Color("ffd23f"), "tile": Color("c59bff"),
		"music": "summit_theme", "night": true,
	},
]

# par time (seconds) used for the time bonus
const PAR_TIMES := [110, 140, 160, 175, 200]


static func get_theme(level: int) -> Dictionary:
	return THEMES[clampi(level, 1, 5) - 1]


static func get_pieces(level: int) -> Array:
	match level:
		1:
			return _level_1()
		2:
			return _level_2()
		3:
			return _level_3()
		4:
			return _level_4()
		_:
			return _level_5()


# ---------------------------------------------------------------- level 1
static func _level_1() -> Array:
	return [
		{"t": "island", "len": 14, "w": 10, "coins": 5, "trees": 3},
		{"t": "gap", "len": 2.5, "coins": 3},
		{"t": "island", "len": 9, "w": 8, "coins": 4, "trees": 2},
		{"t": "bridge", "len": 12, "w": 3.2, "safe": true, "coins": 6},
		{"t": "island", "len": 12, "w": 9, "coins": 4, "trees": 2, "checkpoint": true, "gems": 1},
		{"t": "gap", "len": 3.0, "coins": 3},
		{"t": "stones", "count": 3, "gap": 2.0, "r": 1.9, "coins": true},
		{"t": "gap", "len": 2.0},
		{"t": "island", "len": 12, "w": 9, "coins": 4, "trees": 2, "spikes": [[2.6, 0.0]]},
		{"t": "mplat", "axis": "z", "len": 11, "size": Vector2(4.5, 4.5), "speed": 2.6, "coins": 4},
		{"t": "island", "len": 10, "w": 8, "coins": 3, "checkpoint": true, "gems": 1},
		{"t": "gap", "len": 3.0, "coins": 3},
		{"t": "island", "len": 12, "w": 8, "coins": 5, "trees": 2, "gems": 1},
		{"t": "gap", "len": 3.2, "coins": 3},
		{"t": "island", "len": 14, "w": 10, "coins": 4, "trees": 3, "chest": true},
	]


# ---------------------------------------------------------------- level 2
static func _level_2() -> Array:
	return [
		{"t": "island", "len": 12, "w": 10, "coins": 4, "trees": 3},
		{"t": "gap", "len": 3.5, "coins": 3},
		{"t": "island", "len": 8, "w": 7, "coins": 3, "trees": 1},
		{"t": "bridge", "len": 16, "w": 2.4, "coins": 8},
		{"t": "island", "len": 12, "w": 9, "coins": 4, "checkpoint": true, "gems": 1, "spikes": [[-2.6, -1.0]]},
		{"t": "stones", "count": 4, "gap": 2.6, "r": 1.6, "zig": 1.6, "coins": true},
		{"t": "gap", "len": 2.5},
		{"t": "island", "len": 14, "w": 11, "coins": 4, "trees": 2, "sweepers": [{"x": 0.0, "z": 0.0, "len": 7.0, "speed": 1.3}]},
		{"t": "mplat", "axis": "x", "len": 9.0, "size": Vector2(4, 4), "travel": 7.0, "speed": 2.6, "coins": 3},
		{"t": "island", "len": 10, "w": 8, "checkpoint": true, "gems": 1, "coins": 3},
		{"t": "bridge", "len": 14, "w": 2.2, "crumble": true, "coins": 7},
		{"t": "island", "len": 10, "w": 8, "coins": 4, "spikes": [[2.4, 0.0]]},
		{"t": "gap", "len": 4.2, "coins": 4},
		{"t": "island", "len": 9, "w": 7, "coins": 3, "gems": 1},
		{"t": "mplat", "axis": "z", "len": 14, "size": Vector2(4, 4), "speed": 3.0, "coins": 4},
		{"t": "island", "len": 14, "w": 10, "coins": 4, "trees": 3, "chest": true},
	]


# ---------------------------------------------------------------- level 3
static func _level_3() -> Array:
	return [
		{"t": "island", "len": 12, "w": 10, "coins": 4, "trees": 3},
		{"t": "gap", "len": 4.0, "coins": 3},
		{"t": "round", "r": 4.0, "coins": 2},
		{"t": "gap", "len": 4.5, "coins": 3},
		{"t": "round", "r": 3.5, "coins": 2, "gems": 1},
		{"t": "stones", "count": 4, "gap": 3.0, "r": 1.6, "kind": "blink", "coins": true},
		{"t": "gap", "len": 3.0},
		{"t": "island", "len": 10, "w": 8, "checkpoint": true, "coins": 4, "gems": 1},
		{"t": "mplat", "axis": "y", "len": 6.0, "size": Vector2(4.5, 4.5), "travel": 5.0, "speed": 2.2, "coins": 3},
		{"t": "island", "len": 12, "w": 9, "coins": 4, "sweepers": [{"x": 0.0, "z": 0.0, "len": 6.5, "speed": 1.5}]},
		{"t": "gap", "len": 4.5, "dy": -1.0, "coins": 3},
		{"t": "bridge", "len": 14, "w": 2.2, "crumble": true, "coins": 6},
		{"t": "island", "len": 11, "w": 8, "checkpoint": true, "coins": 3, "gems": 1, "spikes": [[-2.6, 0.0], [2.6, -3.0]]},
		{"t": "mplat", "axis": "z", "len": 15, "size": Vector2(4, 4), "speed": 3.4, "coins": 5},
		{"t": "island", "len": 9, "w": 7, "coins": 3},
		{"t": "gap", "len": 5.0, "coins": 4},
		{"t": "island", "len": 14, "w": 10, "coins": 4, "chest": true},
	]


# ---------------------------------------------------------------- level 4
static func _level_4() -> Array:
	return [
		{"t": "island", "len": 12, "w": 10, "coins": 4, "trees": 2},
		{"t": "gap", "len": 5.0, "coins": 4},
		{"t": "island", "len": 8, "w": 6, "coins": 3},
		{"t": "gap", "len": 5.2, "dy": 0.5, "coins": 4},
		{"t": "island", "len": 10, "w": 8, "checkpoint": true, "coins": 3, "gems": 1, "spikes": [[2.4, -1.0]]},
		{"t": "stones", "count": 5, "gap": 3.2, "r": 1.4, "zig": 2.0, "kind": "crumble", "coins": true},
		{"t": "gap", "len": 3.0},
		{"t": "island", "len": 18, "w": 11, "coins": 4, "gems": 1,
			"sweepers": [{"x": 0.0, "z": -4.0, "len": 7.0, "speed": 1.6}, {"x": 0.0, "z": 4.0, "len": 7.0, "speed": -1.6}]},
		{"t": "mplat", "axis": "x", "len": 9.5, "size": Vector2(3.6, 3.6), "travel": 8.0, "speed": 3.2, "coins": 3},
		{"t": "island", "len": 9, "w": 8, "checkpoint": true, "coins": 3, "gems": 1},
		{"t": "mplat", "axis": "z", "len": 16, "size": Vector2(3.8, 3.8), "speed": 3.6, "coins": 5},
		{"t": "island", "len": 6, "w": 6, "coins": 2},
		{"t": "mplat", "axis": "y", "len": 6.0, "size": Vector2(4.5, 4.5), "travel": 6.0, "speed": 2.6, "coins": 3},
		{"t": "island", "len": 10, "w": 8, "coins": 3, "spikes": [[0.0, -1.0]]},
		{"t": "gap", "len": 5.5, "dy": 0.6, "coins": 5},
		{"t": "island", "len": 9, "w": 7, "checkpoint": true, "coins": 3, "gems": 1},
		{"t": "stones", "count": 4, "gap": 3.4, "r": 1.4, "kind": "blink", "coins": true},
		{"t": "gap", "len": 3.5},
		{"t": "island", "len": 14, "w": 10, "coins": 4, "chest": true},
	]


# ---------------------------------------------------------------- level 5
static func _level_5() -> Array:
	return [
		{"t": "island", "len": 12, "w": 10, "coins": 4},
		{"t": "gap", "len": 5.5, "coins": 4},
		{"t": "round", "r": 3.2, "coins": 2},
		{"t": "gap", "len": 5.8, "coins": 5},
		{"t": "island", "len": 10, "w": 7, "checkpoint": true, "coins": 3, "gems": 1},
		{"t": "stones", "count": 6, "gap": 3.4, "r": 1.3, "zig": 2.2, "kind": "blink", "coins": true},
		{"t": "gap", "len": 3.0},
		{"t": "island", "len": 18, "w": 10, "coins": 4, "gems": 1, "spikes": [[3.4, 0.0]],
			"sweepers": [{"x": 0.0, "z": -4.0, "len": 7.0, "speed": 1.8}, {"x": 0.0, "z": 4.0, "len": 7.0, "speed": -1.8}]},
		{"t": "mplat", "axis": "x", "len": 9.5, "size": Vector2(3.4, 3.4), "travel": 9.0, "speed": 3.6, "coins": 3},
		{"t": "island", "len": 8, "w": 6, "checkpoint": true, "gems": 1, "coins": 3},
		{"t": "bridge", "len": 16, "w": 2.0, "crumble": true, "coins": 8},
		{"t": "island", "len": 10, "w": 7, "coins": 3, "spikes": [[2.0, 0.0], [-2.0, -3.2]]},
		{"t": "mplat", "axis": "y", "len": 6.0, "size": Vector2(4.2, 4.2), "travel": 6.5, "speed": 2.8, "coins": 3},
		{"t": "island", "len": 9, "w": 7, "checkpoint": true, "gems": 1, "coins": 3},
		{"t": "mplat", "axis": "z", "len": 18, "size": Vector2(3.6, 3.6), "speed": 4.0, "coins": 6},
		{"t": "island", "len": 6, "w": 5, "coins": 2},
		{"t": "gap", "len": 6.0, "dy": 0.8, "coins": 5},
		{"t": "stones", "count": 4, "gap": 3.6, "r": 1.3, "zig": 1.5, "kind": "crumble", "dy_step": 0.5, "coins": true},
		{"t": "gap", "len": 3.5},
		{"t": "island", "len": 16, "w": 10, "coins": 5, "gems": 1, "chest": true},
	]
