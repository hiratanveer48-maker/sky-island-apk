class_name MovingPlatform
extends AnimatableBody3D
## Platform that glides smoothly between two points (A <-> B).
## The player is carried along automatically (CharacterBody3D platform support).

var a := Vector3.ZERO
var b := Vector3.ZERO
var _period := 4.0
var _t := 0.0


## `size` = (width x, length z). `p_a` / `p_b` are the CENTRES of the slab.
func setup(size: Vector2, p_a: Vector3, p_b: Vector3, speed: float, color: Color) -> void:
	sync_to_physics = true
	collision_layer = 1
	collision_mask = 0
	a = p_a
	b = p_b
	position = a
	_period = maxf(a.distance_to(b) * PI / maxf(speed, 0.1), 1.0)

	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(size.x, 0.5, size.y)
	cs.shape = sh
	add_child(cs)
	Util.add_box(self, Vector3(size.x, 0.5, size.y), Vector3.ZERO, Util.mat(color.darkened(0.35)))
	Util.add_box(self, Vector3(size.x * 0.92, 0.1, size.y * 0.92), Vector3(0, 0.22, 0), Util.mat(color, 0.5, 0.25))
	Util.add_box(self, Vector3(size.x * 0.5, 0.06, size.y * 0.5), Vector3(0, 0.27, 0), Util.mat(color.lightened(0.45), 0.5, 0.5))


func _physics_process(delta: float) -> void:
	_t += delta
	var w := (1.0 - cos(_t * TAU / _period)) * 0.5
	position = a.lerp(b, w)
