extends Node3D
class_name CameraRig
## Smooth third-person follow camera. Swipe on the free part of the screen
## (right side) to orbit; the camera slowly re-centres behind the player.

var target: Node3D = null
var yaw := 0.0
var pitch := deg_to_rad(27.0)
var distance := 9.5
var height := 1.5

var _follow := Vector3.ZERO
var _pivot: Node3D
var _cam: Camera3D
var _since_drag := 10.0
var _shake := 0.0


func _ready() -> void:
	_pivot = Node3D.new()
	add_child(_pivot)
	_cam = Camera3D.new()
	_cam.fov = 66.0
	_cam.near = 0.2
	_cam.far = 240.0
	_cam.position = Vector3(0, 0, distance)
	_pivot.add_child(_cam)
	_cam.make_current()


func snap() -> void:
	if target:
		_follow = target.global_position + Vector3(0, height, 0)
		global_position = _follow
		rotation.y = yaw
		_pivot.rotation.x = -pitch


func shake(amount: float) -> void:
	_shake = amount


func _process(delta: float) -> void:
	if target == null:
		return
	var tp := target.global_position + Vector3(0, height, 0)
	var kxz := 1.0 - exp(-11.0 * delta)
	var ky := 1.0 - exp(-6.0 * delta)
	_follow.x = lerpf(_follow.x, tp.x, kxz)
	_follow.z = lerpf(_follow.z, tp.z, kxz)
	_follow.y = lerpf(_follow.y, tp.y, ky)
	global_position = _follow

	_since_drag += delta
	if _since_drag > 2.5:
		yaw = lerp_angle(yaw, 0.0, 1.0 - exp(-0.9 * delta))
	rotation.y = yaw
	_pivot.rotation.x = -pitch

	if _shake > 0.001:
		_shake = lerpf(_shake, 0.0, 1.0 - exp(-9.0 * delta))
		_cam.h_offset = randf_range(-_shake, _shake)
		_cam.v_offset = randf_range(-_shake, _shake)
	else:
		_cam.h_offset = 0.0
		_cam.v_offset = 0.0


func _input(event: InputEvent) -> void:
	if event is InputEventScreenDrag:
		if GameState.claimed_touches.has(event.index):
			return
		yaw -= event.relative.x * 0.006
		pitch = clampf(pitch + event.relative.y * 0.004, deg_to_rad(10.0), deg_to_rad(58.0))
		_since_drag = 0.0
