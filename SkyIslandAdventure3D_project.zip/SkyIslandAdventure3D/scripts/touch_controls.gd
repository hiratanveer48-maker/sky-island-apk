class_name TouchControls
extends Control
## On-screen controls: a floating joystick (left half) and a JUMP button
## (bottom right). Fully multi-touch, so you can run and jump at the same
## time. Touches used here are "claimed" so the camera does not orbit.
## Keyboard / gamepad still work on desktop (see game_state.gd input map).

const STICK_RADIUS := 105.0
const JUMP_RADIUS := 92.0

var active := true
var _stick_finger := -1
var _jump_finger := -1
var _stick_origin := Vector2.ZERO
var _stick_pos := Vector2.ZERO
var _rest_pos := Vector2.ZERO
var _jump_center := Vector2.ZERO


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	resized.connect(_layout)
	_layout()


func _layout() -> void:
	_rest_pos = Vector2(190.0, size.y - 175.0)
	_jump_center = Vector2(size.x - 175.0, size.y - 165.0)
	if _stick_finger == -1:
		_stick_origin = _rest_pos
		_stick_pos = _rest_pos
	queue_redraw()


func set_active(on: bool) -> void:
	active = on
	if not on:
		release_all()
	visible = on


func release_all() -> void:
	if _stick_finger != -1:
		GameState.claimed_touches.erase(_stick_finger)
	if _jump_finger != -1:
		GameState.claimed_touches.erase(_jump_finger)
		GameState.touch_jump_released.emit()
	_stick_finger = -1
	_jump_finger = -1
	GameState.touch_move = Vector2.ZERO
	_layout()


func _exit_tree() -> void:
	GameState.touch_move = Vector2.ZERO
	GameState.claimed_touches.clear()


func _input(event: InputEvent) -> void:
	if not active or not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			_press(t.index, t.position)
		else:
			_release(t.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index == _stick_finger:
			_move_stick(d.position)


func _press(index: int, p: Vector2) -> void:
	if _jump_finger == -1 and p.distance_to(_jump_center) <= JUMP_RADIUS * 1.45:
		_jump_finger = index
		GameState.claimed_touches[index] = true
		GameState.touch_jump_pressed.emit()
		queue_redraw()
		return
	if _stick_finger == -1 and p.x < size.x * 0.5 and p.y > size.y * 0.22:
		_stick_finger = index
		GameState.claimed_touches[index] = true
		_stick_origin = Vector2(
			clampf(p.x, STICK_RADIUS + 20.0, size.x * 0.5),
			clampf(p.y, size.y * 0.3, size.y - STICK_RADIUS - 20.0))
		_move_stick(p)


func _release(index: int) -> void:
	if index == _stick_finger:
		GameState.claimed_touches.erase(index)
		_stick_finger = -1
		GameState.touch_move = Vector2.ZERO
		_stick_origin = _rest_pos
		_stick_pos = _rest_pos
		queue_redraw()
	elif index == _jump_finger:
		GameState.claimed_touches.erase(index)
		_jump_finger = -1
		GameState.touch_jump_released.emit()
		queue_redraw()


func _move_stick(p: Vector2) -> void:
	var d := p - _stick_origin
	if d.length() > STICK_RADIUS:
		# the base follows the thumb, so you never run out of room
		_stick_origin += d.normalized() * (d.length() - STICK_RADIUS)
		d = p - _stick_origin
	_stick_pos = _stick_origin + d
	var v := d / STICK_RADIUS
	GameState.touch_move = Vector2.ZERO if v.length() < 0.14 else v.limit_length(1.0)
	queue_redraw()


func _draw() -> void:
	# joystick
	var live := _stick_finger != -1
	var a := 0.34 if live else 0.2
	draw_circle(_stick_origin, STICK_RADIUS, Color(1, 1, 1, a * 0.55))
	draw_arc(_stick_origin, STICK_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, a + 0.2), 4.0, true)
	draw_circle(_stick_pos, 46.0, Color(1, 1, 1, 0.55 if live else 0.32))
	draw_arc(_stick_pos, 46.0, 0.0, TAU, 32, Color(1, 1, 1, 0.85), 3.0, true)
	# jump button
	var down := _jump_finger != -1
	draw_circle(_jump_center, JUMP_RADIUS, Color(1.0, 0.62, 0.1, 0.78 if down else 0.5))
	draw_arc(_jump_center, JUMP_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.85), 5.0, true)
	var c := _jump_center + Vector2(0, -6)
	draw_colored_polygon(PackedVector2Array([c + Vector2(0, -34), c + Vector2(34, 6), c + Vector2(14, 6), c + Vector2(14, 30), c + Vector2(-14, 30), c + Vector2(-14, 6), c + Vector2(-34, 6)]), Color(1, 1, 1, 0.95))
	var font := ThemeDB.fallback_font
	draw_string(font, _jump_center + Vector2(-JUMP_RADIUS, JUMP_RADIUS * 0.78 + 14), "JUMP", HORIZONTAL_ALIGNMENT_CENTER, JUMP_RADIUS * 2.0, 24, Color(1, 1, 1, 0.9))
