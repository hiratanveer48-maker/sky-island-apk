class_name BlinkTile
extends StaticBody3D
## A tile that disappears and re-appears on a timer. It flickers shortly
## before vanishing, and shows a faint ghost outline while it is gone.

var _on := 2.4
var _off := 1.5
var _t := 0.0
var _solid := true
var _shape: CollisionShape3D
var _mesh: Node3D
var _ghost: MeshInstance3D


func setup(size: Vector3, color: Color, on_time: float, off_time: float, offset: float) -> void:
	collision_layer = 1
	collision_mask = 0
	_on = on_time
	_off = off_time
	_t = offset
	_shape = CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	_shape.shape = sh
	add_child(_shape)
	_mesh = Node3D.new()
	add_child(_mesh)
	Util.add_box(_mesh, size, Vector3.ZERO, Util.mat(color.darkened(0.3), 0.4, 0.2))
	Util.add_box(_mesh, Vector3(size.x * 0.9, 0.08, size.z * 0.9), Vector3(0, size.y * 0.5, 0), Util.mat(color, 0.4, 0.6))
	_ghost = Util.add_box(self, size, Vector3.ZERO, Util.mat(Color(color.r, color.g, color.b, 0.18), 1.0, 0.0, true))
	_ghost.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_ghost.visible = false


func _process(delta: float) -> void:
	_t += delta
	var cycle := _on + _off
	var ph := fmod(_t, cycle)
	var solid := ph < _on
	if solid != _solid:
		_solid = solid
		_shape.set_deferred("disabled", not solid)
		_ghost.visible = not solid
	if solid:
		var warn := ph > _on - 0.8
		_mesh.visible = (fmod(_t, 0.2) < 0.1) if warn else true
	else:
		_mesh.visible = false
