class_name SettingsPanel
extends PanelContainer
## Sound + graphics options. Used by the main menu and the pause menu.

signal closed

var allow_reset := false
var _reset_btn: Button
var _reset_armed := false


func _ready() -> void:
	custom_minimum_size = Vector2(700, 0)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 16)
	add_child(vb)
	vb.add_child(UIKit.label("SETTINGS", 50, UIKit.C_GOLD))

	vb.add_child(_slider_row("Music", GameState.music_volume, func(v: float) -> void: GameState.set_music_volume(v), false))
	vb.add_child(_slider_row("Sound effects", GameState.sfx_volume, func(v: float) -> void: GameState.set_sfx_volume(v), true))

	var gfx_row := HBoxContainer.new()
	gfx_row.add_theme_constant_override("separation", 12)
	gfx_row.add_child(_row_label("Graphics"))
	var group := ButtonGroup.new()
	var names := ["Low", "Medium", "High"]
	for i in 3:
		var b := Button.new()
		b.text = names[i]
		b.toggle_mode = true
		b.button_group = group
		b.button_pressed = (GameState.graphics_quality == i)
		b.custom_minimum_size = Vector2(130, 64)
		b.focus_mode = Control.FOCUS_NONE
		b.add_theme_font_size_override("font_size", 28)
		var q := i
		b.pressed.connect(func() -> void:
			Audio.play_sfx("click")
			GameState.set_graphics_quality(q))
		gfx_row.add_child(b)
	vb.add_child(gfx_row)

	var vib_row := HBoxContainer.new()
	vib_row.add_theme_constant_override("separation", 12)
	vib_row.add_child(_row_label("Vibration"))
	var vib := Button.new()
	vib.toggle_mode = true
	vib.button_pressed = GameState.vibration
	vib.text = "ON" if GameState.vibration else "OFF"
	vib.custom_minimum_size = Vector2(130, 64)
	vib.focus_mode = Control.FOCUS_NONE
	vib.add_theme_font_size_override("font_size", 28)
	vib.toggled.connect(func(on: bool) -> void:
		Audio.play_sfx("click")
		GameState.set_vibration(on)
		vib.text = "ON" if on else "OFF")
	vib_row.add_child(vib)
	vb.add_child(vib_row)

	if allow_reset:
		_reset_btn = UIKit.button("Reset saved progress", _on_reset, Vector2(0, 60), 26)
		vb.add_child(_reset_btn)

	vb.add_child(UIKit.button("Back", _close, Vector2(0, 76)))


func _row_label(text: String) -> Label:
	var l := UIKit.label(text, 30, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
	l.custom_minimum_size = Vector2(190, 0)
	return l


func _slider_row(text: String, value: float, on_change: Callable, click_on_release: bool) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	row.add_child(_row_label(text))
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = 0.05
	s.value = value
	s.custom_minimum_size = Vector2(330, 56)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.value_changed.connect(func(v: float) -> void: on_change.call(v))
	if click_on_release:
		s.drag_ended.connect(func(_changed: bool) -> void: Audio.play_sfx("coin"))
	row.add_child(s)
	return row


func _on_reset() -> void:
	if not _reset_armed:
		_reset_armed = true
		_reset_btn.text = "Tap again to confirm"
		return
	GameState.reset_progress()
	_reset_armed = false
	_reset_btn.text = "Progress reset"


func _close() -> void:
	GameState.save_game()
	closed.emit()
