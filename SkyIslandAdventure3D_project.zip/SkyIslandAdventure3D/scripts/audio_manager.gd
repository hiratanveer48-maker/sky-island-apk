extends Node
## Autoload "Audio": sound effects (pooled players) + looping background music.
## Files live in res://audio/sfx/<name>.wav and res://audio/music/<name>.wav -
## replace them with your own sounds using the same file names.

const SFX_NAMES := ["jump", "double_jump", "coin", "diamond", "checkpoint", "hurt", "fall", "land",
		"step", "click", "extra_life", "chest", "win"]
const POOL_SIZE := 10

var _sfx: Dictionary = {}
var _pool: Array[AudioStreamPlayer] = []
var _music: AudioStreamPlayer
var _music_cache: Dictionary = {}
var _current_music := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_buses()
	for n in SFX_NAMES:
		var path := "res://audio/sfx/%s.wav" % n
		if ResourceLoader.exists(path):
			_sfx[n] = load(path)
	for i in POOL_SIZE:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_pool.append(p)
	_music = AudioStreamPlayer.new()
	_music.bus = "Music"
	_music.volume_db = -4.0
	_music.finished.connect(_on_music_finished)
	add_child(_music)
	GameState.settings_changed.connect(apply_volumes)
	apply_volumes()


func _setup_buses() -> void:
	for bus_name in ["Music", "SFX"]:
		if AudioServer.get_bus_index(bus_name) == -1:
			AudioServer.add_bus()
			var idx := AudioServer.bus_count - 1
			AudioServer.set_bus_name(idx, bus_name)
			AudioServer.set_bus_send(idx, "Master")


func apply_volumes() -> void:
	_set_bus("Music", GameState.music_volume)
	_set_bus("SFX", GameState.sfx_volume)


func _set_bus(bus_name: String, linear: float) -> void:
	var idx := AudioServer.get_bus_index(bus_name)
	if idx == -1:
		return
	AudioServer.set_bus_mute(idx, linear <= 0.001)
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(linear, 0.0001)))


func play_sfx(sfx_name: String, pitch: float = 1.0, volume_db: float = 0.0) -> void:
	if not _sfx.has(sfx_name):
		return
	for p in _pool:
		if not p.playing:
			p.stream = _sfx[sfx_name]
			p.pitch_scale = pitch
			p.volume_db = volume_db
			p.play()
			return
	# all busy: steal the first one
	_pool[0].stream = _sfx[sfx_name]
	_pool[0].pitch_scale = pitch
	_pool[0].volume_db = volume_db
	_pool[0].play()


func play_music(track: String) -> void:
	if track == _current_music and _music.playing:
		return
	if not _music_cache.has(track):
		var path := "res://audio/music/%s.wav" % track
		if not ResourceLoader.exists(path):
			return
		_music_cache[track] = load(path)
	_current_music = track
	_music.stream = _music_cache[track]
	_music.play()


func stop_music() -> void:
	_current_music = ""
	_music.stop()


func _on_music_finished() -> void:
	if _current_music != "":
		_music.play()   # loop
