class_name MenuBackground
extends Control
## Animated sky for the main menu: gradient, sun, drifting clouds and
## floating islands. Drawn with a few polygons - very cheap on phones.

var _t := 0.0
var _clouds: Array = []
var _islands: Array = []


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var rng := RandomNumberGenerator.new()
	rng.seed = 12
	for i in 9:
		_clouds.append([rng.randf(), rng.randf_range(0.05, 0.8), rng.randf_range(0.7, 1.5), rng.randf_range(8.0, 26.0)])
	for i in 4:
		_islands.append([rng.randf_range(0.05, 0.95), rng.randf_range(0.18, 0.7), rng.randf_range(70.0, 150.0), rng.randf() * 6.0])


func _process(delta: float) -> void:
	_t += delta
	queue_redraw()


func _draw() -> void:
	var s := size
	var top := Color("2f8cf0")
	var bottom := Color("bfe9ff")
	draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(s.x, 0), Vector2(s.x, s.y), Vector2(0, s.y)]),
			PackedColorArray([top, top, bottom, bottom]))
	# sun
	var sun_c := Vector2(s.x * 0.8, s.y * 0.2)
	draw_circle(sun_c, 150.0, Color(1, 0.95, 0.6, 0.16))
	draw_circle(sun_c, 100.0, Color(1, 0.95, 0.6, 0.28))
	draw_circle(sun_c, 62.0, Color("fff2a8"))
	# far islands
	for isl in _islands:
		var c := Vector2(s.x * isl[0], s.y * isl[1] + sin(_t * 0.8 + isl[3]) * 8.0)
		_draw_island(c, isl[2])
	# clouds (wrap around)
	for cl in _clouds:
		var x := fposmod(cl[0] * (s.x + 500.0) + _t * cl[3], s.x + 500.0) - 250.0
		_draw_cloud(Vector2(x, s.y * cl[1]), cl[2])


func _draw_cloud(c: Vector2, k: float) -> void:
	var col := Color(1, 1, 1, 0.92)
	draw_circle(c + Vector2(-46, 8) * k, 30.0 * k, col)
	draw_circle(c + Vector2(-12, -10) * k, 40.0 * k, col)
	draw_circle(c + Vector2(34, 0) * k, 34.0 * k, col)
	draw_circle(c + Vector2(66, 14) * k, 24.0 * k, col)
	draw_rect(Rect2(c + Vector2(-76, 8) * k, Vector2(166, 30) * k), col)


func _draw_island(c: Vector2, w: float) -> void:
	var rock := PackedVector2Array([c + Vector2(-w * 0.5, 0), c + Vector2(w * 0.5, 0), c + Vector2(w * 0.12, w * 0.55), c + Vector2(-w * 0.1, w * 0.62)])
	draw_colored_polygon(rock, Color("8a6a4c"))
	draw_colored_polygon(PackedVector2Array([c + Vector2(0, 0), c + Vector2(w * 0.5, 0), c + Vector2(w * 0.12, w * 0.55), c + Vector2(-w * 0.1, w * 0.62)]), Color("6e5239"))
	var pts := PackedVector2Array()
	for i in 24:
		var a := TAU * float(i) / 24.0
		pts.append(c + Vector2(cos(a) * w * 0.55, sin(a) * w * 0.1 - w * 0.02))
	draw_colored_polygon(pts, Color("6fd05a"))
	# little tree
	var tx := c.x - w * 0.15
	draw_rect(Rect2(tx - 3, c.y - w * 0.2, 6, w * 0.2), Color("7b5232"))
	draw_colored_polygon(PackedVector2Array([Vector2(tx - w * 0.12, c.y - w * 0.15), Vector2(tx + w * 0.12, c.y - w * 0.15), Vector2(tx, c.y - w * 0.46)]), Color("2f9e57"))
