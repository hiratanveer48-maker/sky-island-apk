class_name Drifter
extends Node3D
## Gently sways a background cloud / far island left and right.

var amplitude := 6.0
var speed := 0.12
var bob := 0.0

var _origin := Vector3.ZERO
var _t := randf() * 20.0


func _ready() -> void:
	_origin = position


func _process(delta: float) -> void:
	_t += delta * speed
	position.x = _origin.x + sin(_t) * amplitude
	if bob > 0.0:
		position.y = _origin.y + sin(_t * 7.0) * bob
