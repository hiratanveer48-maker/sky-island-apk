extends Node
## Autoload "GameState": settings, saved progress (offline, local file),
## input map and a few values shared between scenes.

signal settings_changed
signal touch_jump_pressed
signal touch_jump_released

const SAVE_PATH := "user://sky_island_save.cfg"
const MAX_LEVEL := 5
const LEVEL_NAMES := ["Meadow Hop", "Windy Bridges", "Frozen Peaks", "Sunset Ruins", "Starlight Summit"]

# ---- saved data
var unlocked_level := 1
var high_score := 0
var best_scores := {}   # level (int) -> best score
var best_stars := {}    # level (int) -> 0..3
var total_coins := 0
var music_volume := 0.7
var sfx_volume := 1.0
var graphics_quality := 1   # 0 = Low, 1 = Medium, 2 = High
var vibration := true

# ---- runtime
var current_level := 1
var run_score := 0                # score banked from levels finished in this run
var touch_move := Vector2.ZERO    # written by the on-screen joystick
var claimed_touches := {}         # finger index -> true (touch is used by a UI control)


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_input()
	load_game()
	apply_graphics()


# ------------------------------------------------------------------ input
func _setup_input() -> void:
	_add_action("move_left", [KEY_A, KEY_LEFT])
	_add_action("move_right", [KEY_D, KEY_RIGHT])
	_add_action("move_forward", [KEY_W, KEY_UP])
	_add_action("move_back", [KEY_S, KEY_DOWN])
	_add_action("jump", [KEY_SPACE])
	_add_action("pause", [KEY_ESCAPE, KEY_P])
	_add_joy_axis("move_left", JOY_AXIS_LEFT_X, -1.0)
	_add_joy_axis("move_right", JOY_AXIS_LEFT_X, 1.0)
	_add_joy_axis("move_forward", JOY_AXIS_LEFT_Y, -1.0)
	_add_joy_axis("move_back", JOY_AXIS_LEFT_Y, 1.0)
	var jb := InputEventJoypadButton.new()
	jb.button_index = JOY_BUTTON_A
	InputMap.action_add_event("jump", jb)


func _add_action(action_name: String, keys: Array) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name, 0.2)
	for k in keys:
		var ev := InputEventKey.new()
		ev.physical_keycode = k
		InputMap.action_add_event(action_name, ev)


func _add_joy_axis(action_name: String, axis: int, value: float) -> void:
	var ev := InputEventJoypadMotion.new()
	ev.axis = axis
	ev.axis_value = value
	InputMap.action_add_event(action_name, ev)


# ------------------------------------------------------------------ save / load
func save_game() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("progress", "unlocked_level", unlocked_level)
	cfg.set_value("progress", "high_score", high_score)
	cfg.set_value("progress", "best_scores", best_scores)
	cfg.set_value("progress", "best_stars", best_stars)
	cfg.set_value("progress", "total_coins", total_coins)
	cfg.set_value("settings", "music_volume", music_volume)
	cfg.set_value("settings", "sfx_volume", sfx_volume)
	cfg.set_value("settings", "graphics_quality", graphics_quality)
	cfg.set_value("settings", "vibration", vibration)
	cfg.save(SAVE_PATH)


func load_game() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	unlocked_level = clampi(int(cfg.get_value("progress", "unlocked_level", 1)), 1, MAX_LEVEL)
	high_score = int(cfg.get_value("progress", "high_score", 0))
	best_scores = cfg.get_value("progress", "best_scores", {})
	best_stars = cfg.get_value("progress", "best_stars", {})
	total_coins = int(cfg.get_value("progress", "total_coins", 0))
	music_volume = clampf(float(cfg.get_value("settings", "music_volume", 0.7)), 0.0, 1.0)
	sfx_volume = clampf(float(cfg.get_value("settings", "sfx_volume", 1.0)), 0.0, 1.0)
	graphics_quality = clampi(int(cfg.get_value("settings", "graphics_quality", 1)), 0, 2)
	vibration = bool(cfg.get_value("settings", "vibration", true))


func reset_progress() -> void:
	unlocked_level = 1
	high_score = 0
	best_scores = {}
	best_stars = {}
	total_coins = 0
	run_score = 0
	save_game()


# ------------------------------------------------------------------ progress
func start_level(level: int, fresh_run: bool = true) -> void:
	current_level = clampi(level, 1, MAX_LEVEL)
	if fresh_run:
		run_score = 0


func complete_level(level: int, level_total: int, stars: int, coins: int) -> void:
	run_score += level_total
	if run_score > high_score:
		high_score = run_score
	if level_total > int(best_scores.get(level, 0)):
		best_scores[level] = level_total
	if stars > int(best_stars.get(level, 0)):
		best_stars[level] = stars
	unlocked_level = maxi(unlocked_level, mini(level + 1, MAX_LEVEL))
	total_coins += coins
	save_game()


## Called when a run ends without completing the level (game over).
func note_run_end(score: int) -> void:
	if score > high_score:
		high_score = score
		save_game()


# ------------------------------------------------------------------ settings
func set_music_volume(v: float) -> void:
	music_volume = clampf(v, 0.0, 1.0)
	settings_changed.emit()


func set_sfx_volume(v: float) -> void:
	sfx_volume = clampf(v, 0.0, 1.0)
	settings_changed.emit()


func set_graphics_quality(q: int) -> void:
	graphics_quality = clampi(q, 0, 2)
	apply_graphics()
	settings_changed.emit()


func set_vibration(on: bool) -> void:
	vibration = on
	settings_changed.emit()


func shadows_enabled() -> bool:
	return graphics_quality >= 1


func apply_graphics() -> void:
	var vp := get_tree().root
	match graphics_quality:
		0:
			vp.scaling_3d_scale = 0.65
			vp.msaa_3d = Viewport.MSAA_DISABLED
		1:
			vp.scaling_3d_scale = 0.85
			vp.msaa_3d = Viewport.MSAA_DISABLED
		_:
			vp.scaling_3d_scale = 1.0
			vp.msaa_3d = Viewport.MSAA_2X


func vibrate(ms: int) -> void:
	if vibration and OS.has_feature("mobile"):
		Input.vibrate_handheld(ms)
