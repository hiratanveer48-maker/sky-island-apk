class_name HudLayer
extends CanvasLayer
## In-game UI: counters, touch controls, Pause / Level Complete / Game Over screens.

signal pause_toggled
signal resume_requested
signal restart_requested
signal menu_requested
signal next_requested

var _root: Control
var _controls: TouchControls
var _lives_lbl: Label
var _coins_lbl: Label
var _gems_lbl: Label
var _score_lbl: Label
var _level_lbl: Label
var _toast: Label
var _toast_tween: Tween
var _flash: ColorRect
var _overlay: Control
var _holder: CenterContainer
var _pause_btn: Button
var _last_lives := -1


func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	_root = Control.new()
	_root.theme = UIKit.make_theme()
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_controls = TouchControls.new()
	_root.add_child(_controls)
	_build_top_bar()
	_build_toast()

	_flash = ColorRect.new()
	_flash.color = Color(1, 1, 1, 0)
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_flash)
	_flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_overlay = Control.new()
	_overlay.visible = false
	_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	_root.add_child(_overlay)
	_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.05, 0.14, 0.66)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_overlay.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_holder = CenterContainer.new()
	_overlay.add_child(_holder)
	_holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		pause_toggled.emit()


# ------------------------------------------------------------------ top bar
func _make_chip(kind: int, text: String) -> Array:
	var chip := PanelContainer.new()
	chip.theme_type_variation = "ChipPanel"
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 8)
	hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chip.add_child(hb)
	var icon := HudIcon.new(kind as HudIcon.Kind, 40.0)
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb.add_child(icon)
	var lbl := UIKit.label(text, 34, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
	hb.add_child(lbl)
	return [chip, lbl]


func _build_top_bar() -> void:
	var bar := MarginContainer.new()
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_theme_constant_override("margin_left", 22)
	bar.add_theme_constant_override("margin_top", 16)
	bar.add_theme_constant_override("margin_right", 130)
	_root.add_child(bar)
	bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_child(hb)
	var c1 := _make_chip(HudIcon.Kind.HEART, "x3")
	var c2 := _make_chip(HudIcon.Kind.COIN, "0/0")
	var c3 := _make_chip(HudIcon.Kind.GEM, "0/0")
	_lives_lbl = c1[1]
	_coins_lbl = c2[1]
	_gems_lbl = c3[1]
	hb.add_child(c1[0])
	hb.add_child(c2[0])
	hb.add_child(c3[0])

	var center := VBoxContainer.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_theme_constant_override("separation", 0)
	_root.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	center.offset_top = 14
	_level_lbl = UIKit.label("", 26, Color(1, 1, 1, 0.9))
	_score_lbl = UIKit.label("SCORE 0", 40, UIKit.C_GOLD)
	center.add_child(_level_lbl)
	center.add_child(_score_lbl)
	center.position.x = 0

	_pause_btn = Button.new()
	_pause_btn.text = "II"
	_pause_btn.focus_mode = Control.FOCUS_NONE
	_pause_btn.custom_minimum_size = Vector2(84, 84)
	_pause_btn.add_theme_font_size_override("font_size", 38)
	_pause_btn.pressed.connect(func() -> void:
		Audio.play_sfx("click")
		pause_toggled.emit())
	_root.add_child(_pause_btn)
	_pause_btn.anchor_left = 1.0
	_pause_btn.anchor_right = 1.0
	_pause_btn.offset_left = -108.0
	_pause_btn.offset_right = -24.0
	_pause_btn.offset_top = 16.0
	_pause_btn.offset_bottom = 100.0


func _build_toast() -> void:
	_toast = UIKit.label("", 54, Color.WHITE)
	_toast.modulate.a = 0.0
	_root.add_child(_toast)
	_toast.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_toast.offset_top = 150
	_toast.add_theme_constant_override("outline_size", 10)


# ------------------------------------------------------------------ updates (called by game.gd)
func setup(level: int, level_name: String) -> void:
	_level_lbl.text = "LEVEL %d - %s" % [level, level_name.to_upper()]


func set_coins(c: int, total: int) -> void:
	_coins_lbl.text = "%d/%d" % [c, total]


func set_gems(g: int, total: int) -> void:
	_gems_lbl.text = "%d/%d" % [g, total]


func set_score(s: int) -> void:
	_score_lbl.text = "SCORE %d" % s


func set_lives(n: int) -> void:
	_lives_lbl.text = "x%d" % n
	if _last_lives != -1 and n != _last_lives:
		var tw := create_tween()
		_lives_lbl.pivot_offset = _lives_lbl.size * 0.5
		_lives_lbl.scale = Vector2(1.5, 1.5)
		tw.tween_property(_lives_lbl, "scale", Vector2.ONE, 0.3)
	_last_lives = n


func toast(text: String, color: Color = Color.WHITE, seconds: float = 1.6) -> void:
	_toast.text = text
	_toast.add_theme_color_override("font_color", color)
	if _toast_tween:
		_toast_tween.kill()
	_toast.modulate.a = 1.0
	_toast_tween = create_tween()
	_toast_tween.tween_interval(seconds)
	_toast_tween.tween_property(_toast, "modulate:a", 0.0, 0.5)


func flash(color: Color = Color(1, 1, 1, 0.55)) -> void:
	_flash.color = color
	var tw := create_tween()
	tw.tween_property(_flash, "color:a", 0.0, 0.5)


func set_controls_active(on: bool) -> void:
	_controls.set_active(on)
	_pause_btn.visible = on


# ------------------------------------------------------------------ overlay panels
func _panel(title: String, title_color: Color = UIKit.C_GOLD) -> VBoxContainer:
	for c in _holder.get_children():
		_holder.remove_child(c)
		c.queue_free()
	var pc := PanelContainer.new()
	_holder.add_child(pc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	pc.add_child(vb)
	vb.add_child(UIKit.label(title, 54, title_color))
	_overlay.visible = true
	_controls.set_active(false)
	_pause_btn.visible = false
	return vb


func hide_overlay() -> void:
	_overlay.visible = false
	for c in _holder.get_children():
		_holder.remove_child(c)
		c.queue_free()
	_controls.set_active(true)
	_pause_btn.visible = true


func show_pause() -> void:
	var vb := _panel("PAUSED")
	vb.custom_minimum_size = Vector2(420, 0)
	vb.add_child(UIKit.button("Resume", func() -> void: resume_requested.emit()))
	vb.add_child(UIKit.button("Restart", func() -> void: restart_requested.emit()))
	vb.add_child(UIKit.button("Settings", _show_settings))
	vb.add_child(UIKit.button("Main Menu", func() -> void: menu_requested.emit()))


func _show_settings() -> void:
	for c in _holder.get_children():
		_holder.remove_child(c)
		c.queue_free()
	var sp := SettingsPanel.new()
	sp.closed.connect(show_pause)
	_holder.add_child(sp)


func show_game_over(score: int) -> void:
	var vb := _panel("OUT OF LIVES", Color("ff6b6b"))
	vb.custom_minimum_size = Vector2(460, 0)
	vb.add_child(UIKit.label("Score: %d" % score, 38))
	vb.add_child(UIKit.label("High score: %d" % GameState.high_score, 30, Color(1, 1, 1, 0.85)))
	vb.add_child(UIKit.button("Try Again", func() -> void: restart_requested.emit()))
	vb.add_child(UIKit.button("Main Menu", func() -> void: menu_requested.emit()))


## info: stars, coins, coin_total, gems, gem_total, time, rows[[label, value]...],
##       level_total, run_total, new_high, is_last
func show_level_complete(info: Dictionary) -> void:
	var is_last: bool = info.get("is_last", false)
	var vb := _panel("ADVENTURE COMPLETE!" if is_last else "LEVEL COMPLETE!")
	vb.add_theme_constant_override("separation", 10)

	var stars := HBoxContainer.new()
	stars.alignment = BoxContainer.ALIGNMENT_CENTER
	stars.add_theme_constant_override("separation", 10)
	for i in 3:
		var s := HudIcon.new(HudIcon.Kind.STAR, 66.0)
		s.set_lit(i < int(info.get("stars", 1)))
		stars.add_child(s)
	vb.add_child(stars)

	var line := "Coins %d/%d     Diamonds %d/%d     Time %s" % [
		info.get("coins", 0), info.get("coin_total", 0), info.get("gems", 0), info.get("gem_total", 0),
		UIKit.format_time(info.get("time", 0.0))]
	vb.add_child(UIKit.label(line, 30))

	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 22)
	grid.add_theme_constant_override("v_separation", 2)
	var rows: Array = info.get("rows", [])
	for r in rows:
		grid.add_child(UIKit.label(String(r[0]), 26, Color(1, 1, 1, 0.85), HORIZONTAL_ALIGNMENT_LEFT))
		grid.add_child(UIKit.label("+%d" % int(r[1]), 26, UIKit.C_GOLD, HORIZONTAL_ALIGNMENT_RIGHT))
	var center := CenterContainer.new()
	center.add_child(grid)
	vb.add_child(center)

	vb.add_child(UIKit.label("LEVEL SCORE  %d" % int(info.get("level_total", 0)), 44, UIKit.C_GOLD))
	if is_last:
		vb.add_child(UIKit.label("TOTAL SCORE  %d" % int(info.get("run_total", 0)), 34))
	if info.get("new_high", false):
		vb.add_child(UIKit.label("NEW HIGH SCORE!", 34, Color("7dff9b")))

	var btns := HBoxContainer.new()
	btns.alignment = BoxContainer.ALIGNMENT_CENTER
	btns.add_theme_constant_override("separation", 14)
	if not is_last:
		btns.add_child(UIKit.button("Next Level", func() -> void: next_requested.emit(), Vector2(250, 76)))
	btns.add_child(UIKit.button("Replay", func() -> void: restart_requested.emit(), Vector2(190, 76)))
	btns.add_child(UIKit.button("Menu", func() -> void: menu_requested.emit(), Vector2(170, 76)))
	vb.add_child(btns)
