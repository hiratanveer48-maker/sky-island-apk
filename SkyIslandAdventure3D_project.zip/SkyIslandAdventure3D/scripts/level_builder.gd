class_name LevelBuilder
extends RefCounted
## Builds a level (islands, bridges, platforms, hazards, pickups, scenery) from
## the piece list in levels_data.gd. Everything is created from simple shapes,
## so no 3D model files are needed.

var root: Node3D
var game = null            # the Game node (callbacks: on_collected / on_checkpoint / on_hazard / on_chest)
var theme: Dictionary = {}
var cursor := Vector3.ZERO # where the next piece starts (centre of its near edge, at surface height)
var spawn_pos := Vector3(0, 0.7, -3.0)
var coin_total := 0
var gem_total := 0
var kill_y := -40.0
var length_z := 0.0
var chest_pos := Vector3.ZERO

var _rng := RandomNumberGenerator.new()
var _min_y := 0.0
var _first_island := true


func build(level: int, game_node, level_root: Node3D) -> void:
	game = game_node
	root = level_root
	theme = LevelsData.get_theme(level)
	_rng.seed = 4000 + level * 91
	for p in LevelsData.get_pieces(level):
		_build_piece(p)
	length_z = -cursor.z
	kill_y = _min_y - 28.0
	_add_scenery()


func _build_piece(p: Dictionary) -> void:
	match String(p.get("t", "")):
		"island":
			_island(p)
		"round":
			_round_island(p)
		"gap":
			_gap(p)
		"bridge":
			_bridge(p)
		"stones":
			_stones(p)
		"mplat":
			_mplat(p)
		_:
			push_warning("Unknown piece type: %s" % str(p))


# ------------------------------------------------------------------ pickups & props
func _add_collectible(pos: Vector3, gem: bool) -> void:
	var c := Collectible.new()
	c.is_gem = gem
	c.position = pos
	root.add_child(c)
	c.collected.connect(Callable(game, "on_collected"))
	if gem:
		gem_total += 1
	else:
		coin_total += 1


func _coin_line(a: Vector3, b: Vector3, n: int) -> void:
	for i in n:
		var t := 0.5 if n == 1 else float(i) / float(n - 1)
		_add_collectible(a.lerp(b, t), false)


func _coin_arc(a: Vector3, b: Vector3, n: int, height: float) -> void:
	for i in n:
		var t := 0.5 if n == 1 else lerpf(0.1, 0.9, float(i) / float(n - 1))
		var pos := a.lerp(b, t)
		pos.y += 1.2 + height * sin(PI * t)
		_add_collectible(pos, false)


func _add_checkpoint(pos: Vector3) -> void:
	var cp := Checkpoint.new()
	cp.position = pos
	root.add_child(cp)
	cp.reached.connect(Callable(game, "on_checkpoint"))


func _add_spikes(pos: Vector3) -> void:
	var s := SpikeTrap.new()
	s.position = pos
	root.add_child(s)
	s.touched.connect(Callable(game, "on_hazard"))


func _add_sweeper(pos: Vector3, length: float, speed: float) -> void:
	var s := Spinner.new()
	s.setup(length, speed)
	s.position = pos
	root.add_child(s)


func _add_chest(pos: Vector3) -> void:
	var c := TreasureChest.new()
	c.position = pos
	root.add_child(c)
	c.opened.connect(Callable(game, "on_chest"))
	chest_pos = pos


func _add_tree(parent: Node3D, pos: Vector3, s: float) -> void:
	var t := Node3D.new()
	t.position = pos
	t.scale = Vector3.ONE * s
	parent.add_child(t)
	var snowy: bool = theme.get("grass", Color.WHITE).get_luminance() > 0.85
	var leaf := Util.mat(Color("2f9e57") if not snowy else Color("4aa583"))
	var leaf2 := Util.mat(Color("3bb868") if not snowy else Color("6cc3a0"))
	Util.add_cyl(t, 0.16, 0.2, 1.0, Vector3(0, 0.5, 0), Util.mat(Color("7b5232")), 6)
	Util.add_cyl(t, 0.0, 0.95, 1.5, Vector3(0, 1.55, 0), leaf, 8)
	Util.add_cyl(t, 0.0, 0.7, 1.2, Vector3(0, 2.3, 0), leaf2, 8)


# ------------------------------------------------------------------ islands
func _rock_under(parent: Node3D, w: float, l: float, y_top: float) -> void:
	# inverted square pyramid; pivot is scaled along Z to fit rectangular islands
	var h := clampf(maxf(w, l) * 0.5, 2.5, 6.0)
	var pivot := Node3D.new()
	pivot.position = Vector3(0, y_top - h * 0.5, 0)
	pivot.scale = Vector3(1, 1, l / w)
	parent.add_child(pivot)
	var mi := Util.add_cyl(pivot, w * 0.7071, 0.25, h, Vector3.ZERO, Util.mat(theme.rock), 4)
	mi.rotation_degrees.y = 45.0


func _island(p: Dictionary) -> void:
	var w: float = p.get("w", 9.0)
	var l: float = p.get("len", 10.0)
	var entry := cursor + Vector3(p.get("dx", 0.0), p.get("dy", 0.0), 0.0)
	var center := entry + Vector3(0, 0, -l * 0.5)
	var body := Util.make_static_box(Vector3(w, 1.0, l))
	(body.get_child(0) as Node3D).position.y = -0.5
	body.position = center
	root.add_child(body)
	Util.add_box(body, Vector3(w, 0.4, l), Vector3(0, -0.2, 0), Util.mat(theme.grass))
	Util.add_box(body, Vector3(w * 0.97, 0.4, l * 0.97), Vector3(0, -0.6, 0), Util.mat(theme.dirt))
	_rock_under(body, w * 0.96, l * 0.96, -0.8)
	_decorate(center, w, l, p, false)
	if _first_island:
		_first_island = false
		spawn_pos = entry + Vector3(0, 0.7, -3.0)
	cursor = entry + Vector3(0, 0, -l)
	_min_y = minf(_min_y, entry.y)


func _round_island(p: Dictionary) -> void:
	var r: float = p.get("r", 4.0)
	var entry := cursor + Vector3(p.get("dx", 0.0), p.get("dy", 0.0), 0.0)
	var center := entry + Vector3(0, 0, -r)
	_make_round(center, r)
	_decorate(center, r * 2.0, r * 2.0, p, true)
	cursor = entry + Vector3(0, 0, -2.0 * r)
	_min_y = minf(_min_y, entry.y)


func _make_round(center: Vector3, r: float) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var cs := CollisionShape3D.new()
	var sh := CylinderShape3D.new()
	sh.radius = r
	sh.height = 1.0
	cs.shape = sh
	cs.position = Vector3(0, -0.5, 0)
	body.add_child(cs)
	body.position = center
	root.add_child(body)
	Util.add_cyl(body, r, r, 0.4, Vector3(0, -0.2, 0), Util.mat(theme.grass), 18)
	Util.add_cyl(body, r * 0.97, r * 0.9, 0.4, Vector3(0, -0.6, 0), Util.mat(theme.dirt), 18)
	var h := clampf(r * 1.3, 2.0, 5.0)
	Util.add_cyl(body, r * 0.88, 0.2, h, Vector3(0, -0.8 - h * 0.5, 0), Util.mat(theme.rock), 10)
	return body


## Coins, gems, trees, checkpoint, spikes, sweepers and the chest for one island.
func _decorate(center: Vector3, w: float, l: float, p: Dictionary, is_round: bool) -> void:
	var half_w := w * 0.5
	var half_l := l * 0.5
	var margin := 1.5 if not is_round else 1.2

	var trees: int = p.get("trees", 0)
	if w >= 6.0:
		for i in trees:
			var side := -1.0 if i % 2 == 0 else 1.0
			var tx := side * (half_w - 0.9 - _rng.randf() * 0.5)
			var tz := _rng.randf_range(-half_l + 1.4, half_l - 1.4)
			if is_round:
				tx *= 0.7
			_add_tree(root, center + Vector3(tx, 0, tz), _rng.randf_range(0.85, 1.2))

	var n: int = p.get("coins", 0)
	if n > 0:
		_coin_line(center + Vector3(0, 1.0, half_l - margin), center + Vector3(0, 1.0, -half_l + margin), n)

	var g: int = p.get("gems", 0)
	for i in g:
		var side := -1.0 if i % 2 == 0 else 1.0
		var gx := side * maxf(half_w - 1.4, 0.0)
		var gz := lerpf(half_l * 0.3, -half_l * 0.3, 0.5 if g == 1 else float(i) / float(g - 1))
		_add_collectible(center + Vector3(gx, 1.2, gz), true)

	if p.get("checkpoint", false):
		var fx := clampf(half_w - 1.1, 0.0, 3.5)
		_add_checkpoint(center + Vector3(fx, 0, half_l * 0.25))

	for s in p.get("spikes", []):
		_add_spikes(center + Vector3(s[0], 0, s[1]))

	for sw in p.get("sweepers", []):
		_add_sweeper(center + Vector3(sw.get("x", 0.0), 0, sw.get("z", 0.0)), sw.get("len", 7.0), sw.get("speed", 1.5))

	if p.get("chest", false):
		_add_chest(center + Vector3(0, 0, -half_l + 2.6))


# ------------------------------------------------------------------ gap / bridge / stones / platforms
func _gap(p: Dictionary) -> void:
	var l: float = p.get("len", 3.0)
	var dy: float = p.get("dy", 0.0)
	var a := cursor
	var b := cursor + Vector3(0, dy, -l)
	var n: int = p.get("coins", 0)
	if n > 0:
		_coin_arc(a, b, n, 1.5)
	cursor = b
	_min_y = minf(_min_y, b.y)


func _bridge(p: Dictionary) -> void:
	var l: float = p.get("len", 10.0)
	var w: float = p.get("w", 2.4)
	var crumble: bool = p.get("crumble", false)
	var safe: bool = p.get("safe", false)
	var entry := cursor + Vector3(p.get("dx", 0.0), p.get("dy", 0.0), 0.0)
	var wood: Color = theme.wood

	if crumble:
		var n := maxi(2, int(round(l / 1.6)))
		var seg := l / n
		for i in n:
			var tile := CrumbleTile.new()
			tile.setup(Vector3(w, 0.25, seg * 0.94), wood if i % 2 == 0 else wood.darkened(0.12))
			tile.position = entry + Vector3(0, -0.125, -(i + 0.5) * seg)
			root.add_child(tile)
	else:
		var deck := Util.make_static_box(Vector3(w, 0.3, l))
		deck.position = entry + Vector3(0, -0.15, -l * 0.5)
		root.add_child(deck)
		var n := maxi(2, int(round(l / 0.9)))
		var seg := l / n
		for i in n:
			var mat := Util.mat(wood if i % 2 == 0 else wood.darkened(0.12))
			Util.add_box(deck, Vector3(w, 0.24, seg * 0.88), Vector3(0, 0.03, l * 0.5 - (i + 0.5) * seg), mat)

	# rope rails + posts (visual)
	var rope := Util.mat(Color("d9c7a0"))
	var post := Util.mat(wood.darkened(0.3))
	for sx in [-1.0, 1.0]:
		Util.add_box(root, Vector3(0.07, 0.07, l), entry + Vector3(sx * w * 0.5, 0.95, -l * 0.5), rope)
		var posts := maxi(2, int(l / 3.0) + 1)
		for k in posts:
			var z := -float(k) * l / float(posts - 1)
			Util.add_box(root, Vector3(0.14, 1.0, 0.14), entry + Vector3(sx * w * 0.5, 0.4, z), post)
	if safe:
		for sx in [-1.0, 1.0]:
			var wall := Util.make_static_box(Vector3(0.2, 1.6, l))
			wall.position = entry + Vector3(sx * (w * 0.5 + 0.1), 0.8, -l * 0.5)
			root.add_child(wall)

	var c: int = p.get("coins", 0)
	if c > 0:
		_coin_line(entry + Vector3(0, 1.0, -0.8), entry + Vector3(0, 1.0, -l + 0.8), c)
	cursor = entry + Vector3(0, 0, -l)
	_min_y = minf(_min_y, entry.y)


func _stones(p: Dictionary) -> void:
	var count: int = p.get("count", 3)
	var gap: float = p.get("gap", 3.0)
	var r: float = p.get("r", 1.6)
	var zig: float = p.get("zig", 0.0)
	var kind: String = p.get("kind", "round")
	var dy_step: float = p.get("dy_step", 0.0)
	var coins: bool = p.get("coins", false)
	var base_x := cursor.x
	var pos := cursor
	for i in count:
		var side := 1.0 if i % 2 == 0 else -1.0
		var c := Vector3(base_x + side * zig * 0.5, pos.y + dy_step, pos.z - gap - r)
		match kind:
			"crumble":
				var tile := CrumbleTile.new()
				tile.setup(Vector3(r * 2.0, 0.5, r * 2.0), Color(theme.dirt).lightened(0.1))
				tile.position = c + Vector3(0, -0.25, 0)
				root.add_child(tile)
			"blink":
				var tile := BlinkTile.new()
				tile.setup(Vector3(r * 2.0, 0.5, r * 2.0), theme.tile, 2.6, 1.4, float(i) * 1.1)
				tile.position = c + Vector3(0, -0.25, 0)
				root.add_child(tile)
			_:
				_make_round(c, r)
		if coins:
			_add_collectible(c + Vector3(0, 1.1, 0), false)
		pos = Vector3(base_x, c.y, c.z - r)
		_min_y = minf(_min_y, c.y)
	cursor = pos


func _mplat(p: Dictionary) -> void:
	var axis: String = p.get("axis", "z")
	var l: float = p.get("len", 10.0)
	var size: Vector2 = p.get("size", Vector2(4, 4))
	var speed: float = p.get("speed", 2.5)
	var travel: float = p.get("travel", 6.0)
	var entry := cursor + Vector3(p.get("dx", 0.0), p.get("dy", 0.0), 0.0)
	var y := entry.y - 0.25
	var zc := entry.z - l * 0.5
	var a: Vector3
	var b: Vector3
	var n: int = p.get("coins", 0)
	match axis:
		"x":
			a = Vector3(entry.x - travel * 0.5, y, zc)
			b = Vector3(entry.x + travel * 0.5, y, zc)
			if n > 0:
				_coin_line(a + Vector3(0, 1.4, 0), b + Vector3(0, 1.4, 0), n)
		"y":
			a = Vector3(entry.x, y, zc)
			b = Vector3(entry.x, y + travel, zc)
			if n > 0:
				_coin_line(a + Vector3(0, 1.4, 0), b + Vector3(0, 1.4, 0), n)
		_:
			a = Vector3(entry.x, y, entry.z - size.y * 0.5 - 0.25)
			b = Vector3(entry.x, y, entry.z - l + size.y * 0.5 + 0.25)
			if n > 0:
				_coin_line(a + Vector3(0, 1.4, 0), b + Vector3(0, 1.4, 0), n)
	var mp := MovingPlatform.new()
	mp.setup(size, a, b, speed, theme.plat)
	root.add_child(mp)
	cursor = entry + Vector3(0, travel if axis == "y" else 0.0, -l)
	_min_y = minf(_min_y, entry.y)


# ------------------------------------------------------------------ background scenery
func _add_scenery() -> void:
	var z_far := -length_z - 40.0
	var cloud_mat := Util.mat(Color(1, 1, 1), 1.0, 0.0, true)
	if theme.get("night", false):
		cloud_mat = Util.mat(Color("8a86d6"), 1.0, 0.0, true)
	for i in 14:
		var c := Drifter.new()
		c.position = Vector3(_pick_side() * _rng.randf_range(22, 90), _rng.randf_range(-40, 12), _rng.randf_range(z_far, 40))
		c.amplitude = _rng.randf_range(3, 9)
		c.speed = _rng.randf_range(0.05, 0.14)
		root.add_child(c)
		var s := _rng.randf_range(2.5, 5.0)
		Util.add_sphere(c, s, Vector3.ZERO, cloud_mat, Vector3(1.6, 0.6, 1.0), 8).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		Util.add_sphere(c, s * 0.75, Vector3(s * 1.1, -s * 0.1, 0), cloud_mat, Vector3(1.4, 0.55, 1.0), 8).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		Util.add_sphere(c, s * 0.7, Vector3(-s * 1.2, -s * 0.12, 0.3), cloud_mat, Vector3(1.4, 0.5, 1.0), 8).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	for i in 10:
		var isl := Drifter.new()
		isl.position = Vector3(_pick_side() * _rng.randf_range(30, 75), _rng.randf_range(-30, 18), _rng.randf_range(z_far, 30))
		isl.amplitude = 0.0
		isl.bob = _rng.randf_range(0.2, 0.5)
		isl.speed = _rng.randf_range(0.2, 0.4)
		root.add_child(isl)
		var r := _rng.randf_range(3.0, 7.0)
		Util.add_cyl(isl, r, r, 0.7, Vector3.ZERO, Util.mat(theme.grass), 12).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		Util.add_cyl(isl, r * 0.95, 0.3, r * 1.3, Vector3(0, -0.35 - r * 0.65, 0), Util.mat(theme.rock), 8).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		if r > 4.0:
			_add_tree(isl, Vector3(_rng.randf_range(-1.5, 1.5), 0.35, _rng.randf_range(-1.5, 1.5)), _rng.randf_range(1.2, 1.8))


func _pick_side() -> float:
	return -1.0 if _rng.randf() < 0.5 else 1.0
