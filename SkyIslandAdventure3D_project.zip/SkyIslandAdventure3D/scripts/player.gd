extends CharacterBody3D
class_name Player
## Third-person player: smooth run, jump (+ double jump, coyote time, jump buffer),
## procedural character model with run / idle / jump / fall / celebrate animations.

const SPEED := 7.5
const ACCEL_GROUND := 55.0
const ACCEL_AIR := 24.0
const FRICTION := 60.0
const GRAVITY := 30.0
const FALL_GRAVITY_MULT := 1.35
const JUMP_VELOCITY := 10.5
const DOUBLE_JUMP_VELOCITY := 9.5
const MAX_FALL_SPEED := 38.0
const COYOTE_TIME := 0.12
const JUMP_BUFFER := 0.14

var camera_rig: Node3D = null   # CameraRig (needs a "yaw" property)
var controls_enabled := true
var celebrating := false

# test hooks (used by the automated bot, never by the real game)
var ai_enabled := false
var ai_move := Vector2.ZERO
var ai_jump := false

var _coyote := 0.0
var _jump_buffer := 0.0
var _air_jumps := 1
var _knock_time := 0.0
var _was_on_floor := true
var _run_phase := 0.0
var _last_step_half := 0
var _idle_t := 0.0
var _squash_tween: Tween

# model parts
var _model: Node3D        # yaw + squash/stretch (origin at feet)
var _flip: Node3D         # somersault pivot (double jump)
var _parts: Node3D
var _arm_l: Node3D
var _arm_r: Node3D
var _leg_l: Node3D
var _leg_r: Node3D
var _torso: Node3D
var _blob: MeshInstance3D
var _ray: RayCast3D
var _dust: CPUParticles3D


func _ready() -> void:
	add_to_group("player")
	collision_layer = 2
	collision_mask = 1
	floor_snap_length = 0.35
	floor_max_angle = deg_to_rad(50.0)
	platform_on_leave = CharacterBody3D.PLATFORM_ON_LEAVE_ADD_VELOCITY
	_build_model()
	_build_blob_shadow()
	_build_dust()
	GameState.touch_jump_pressed.connect(_on_touch_jump_pressed)
	GameState.touch_jump_released.connect(_on_touch_jump_released)


# ------------------------------------------------------------------ model
func _build_model() -> void:
	_model = Node3D.new()
	_model.name = "Model"
	add_child(_model)
	_flip = Node3D.new()
	_flip.position = Vector3(0, 0.9, 0)
	_model.add_child(_flip)
	_parts = Node3D.new()
	_parts.position = Vector3(0, -0.9, 0)
	_flip.add_child(_parts)

	var shirt := Util.mat(Color("2f7bff"))
	var pants := Util.mat(Color("2b3a67"))
	var skin := Util.mat(Color("ffd2a1"))
	var hat := Util.mat(Color("ff4d4d"))
	var dark := Util.mat(Color("1b1b2b"))
	var pack := Util.mat(Color("c98a3b"))
	var shoe := Util.mat(Color("f2f2f2"))

	_torso = Node3D.new()
	_torso.position = Vector3(0, 0.78, 0)
	_parts.add_child(_torso)
	Util.add_capsule(_torso, 0.30, 0.82, Vector3(0, 0.0, 0), shirt)
	Util.add_box(_torso, Vector3(0.44, 0.5, 0.2), Vector3(0, 0.05, 0.3), pack)          # backpack
	Util.add_box(_torso, Vector3(0.5, 0.08, 0.34), Vector3(0, -0.3, 0), Util.mat(Color("ffd23f")))  # belt
	# head
	var head := Node3D.new()
	head.position = Vector3(0, 0.62, 0)
	_torso.add_child(head)
	Util.add_sphere(head, 0.29, Vector3.ZERO, skin)
	Util.add_sphere(head, 0.05, Vector3(-0.1, 0.03, -0.26), dark, Vector3.ONE, 8)   # eyes
	Util.add_sphere(head, 0.05, Vector3(0.1, 0.03, -0.26), dark, Vector3.ONE, 8)
	Util.add_sphere(head, 0.3, Vector3(0, 0.1, 0.02), hat, Vector3(1.0, 0.7, 1.0))  # cap dome
	Util.add_box(head, Vector3(0.42, 0.05, 0.32), Vector3(0, 0.06, -0.3), hat)      # cap brim
	# arms (pivot at the shoulder; swing around X)
	_arm_l = _make_limb(Vector3(-0.42, 0.78 + 0.22, 0), 0.1, 0.5, shirt, skin)
	_arm_r = _make_limb(Vector3(0.42, 0.78 + 0.22, 0), 0.1, 0.5, shirt, skin)
	_parts.add_child(_arm_l)
	_parts.add_child(_arm_r)
	# legs (pivot at the hip)
	_leg_l = _make_limb(Vector3(-0.17, 0.5, 0), 0.12, 0.5, pants, shoe)
	_leg_r = _make_limb(Vector3(0.17, 0.5, 0), 0.12, 0.5, pants, shoe)
	_parts.add_child(_leg_l)
	_parts.add_child(_leg_r)


func _make_limb(pivot_pos: Vector3, r: float, length: float, mat: Material, end_mat: Material) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = pivot_pos
	Util.add_capsule(pivot, r, length, Vector3(0, -length * 0.5, 0), mat, 8)
	Util.add_sphere(pivot, r * 1.05, Vector3(0, -length + r * 0.3, -0.02), end_mat, Vector3(1, 0.9, 1.3), 8)
	return pivot


func _build_blob_shadow() -> void:
	_blob = MeshInstance3D.new()
	var m := CylinderMesh.new()
	m.top_radius = 0.5
	m.bottom_radius = 0.5
	m.height = 0.02
	m.radial_segments = 14
	m.rings = 1
	_blob.mesh = m
	_blob.material_override = Util.mat(Color(0, 0, 0, 0.35), 1.0, 0.0, true)
	_blob.top_level = true
	_blob.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_blob)
	_ray = RayCast3D.new()
	_ray.target_position = Vector3(0, -60, 0)
	_ray.collision_mask = 1
	_ray.position = Vector3(0, 0.5, 0)
	add_child(_ray)


func _build_dust() -> void:
	_dust = CPUParticles3D.new()
	_dust.amount = 10
	_dust.lifetime = 0.45
	_dust.one_shot = true
	_dust.explosiveness = 1.0
	_dust.emitting = false
	_dust.direction = Vector3(0, 1, 0)
	_dust.spread = 85.0
	_dust.initial_velocity_min = 1.0
	_dust.initial_velocity_max = 2.6
	_dust.gravity = Vector3(0, -2.0, 0)
	_dust.scale_amount_min = 0.6
	_dust.scale_amount_max = 1.2
	var mesh := SphereMesh.new()
	mesh.radius = 0.09
	mesh.height = 0.18
	mesh.radial_segments = 6
	mesh.rings = 3
	_dust.mesh = mesh
	_dust.material_override = Util.mat(Color(1, 1, 1, 0.7), 1.0, 0.0, true)
	_dust.top_level = true
	add_child(_dust)


# ------------------------------------------------------------------ input
func _on_touch_jump_pressed() -> void:
	_jump_buffer = JUMP_BUFFER


func _on_touch_jump_released() -> void:
	pass


func _get_move_input() -> Vector2:
	if not controls_enabled:
		return Vector2.ZERO
	if ai_enabled:
		return ai_move
	var v := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if GameState.touch_move.length() > 0.01:
		v = GameState.touch_move
	return v


func _physics_process(delta: float) -> void:
	var on_floor := is_on_floor()
	var move_in := _get_move_input()
	var yaw := 0.0
	if camera_rig != null:
		yaw = camera_rig.yaw
	var dir := Basis(Vector3.UP, yaw) * Vector3(move_in.x, 0.0, move_in.y)
	if dir.length() > 1.0:
		dir = dir.normalized()

	# keyboard / gamepad / bot jump
	if controls_enabled:
		if Input.is_action_just_pressed("jump") or (ai_enabled and ai_jump):
			_jump_buffer = JUMP_BUFFER

	# floor bookkeeping
	if on_floor:
		_coyote = COYOTE_TIME
		_air_jumps = 1
		if not _was_on_floor:
			_on_landed()
	else:
		_coyote -= delta
	_jump_buffer -= delta
	_knock_time = maxf(0.0, _knock_time - delta)

	# gravity
	if not on_floor:
		var g := GRAVITY
		if velocity.y < 0.0:
			g *= FALL_GRAVITY_MULT
		velocity.y = maxf(velocity.y - g * delta, -MAX_FALL_SPEED)

	# jumping
	if controls_enabled and _jump_buffer > 0.0:
		if _coyote > 0.0:
			_do_jump()
		elif _air_jumps > 0:
			_do_double_jump()
	if celebrating and on_floor:
		velocity.y = 8.5
		_dust_burst()

	# horizontal movement
	var target := dir * SPEED
	var accel := ACCEL_GROUND if on_floor else ACCEL_AIR
	if _knock_time > 0.0:
		accel = 4.0
	elif dir.length() < 0.05 and on_floor:
		accel = FRICTION
	velocity.x = move_toward(velocity.x, target.x, accel * delta)
	velocity.z = move_toward(velocity.z, target.z, accel * delta)

	move_and_slide()
	_was_on_floor = on_floor or is_on_floor()

	# face direction of travel
	if dir.length() > 0.1:
		var ang := atan2(-dir.x, -dir.z)
		_model.rotation.y = lerp_angle(_model.rotation.y, ang, 1.0 - exp(-16.0 * delta))
	_update_blob()


func _do_jump() -> void:
	velocity.y = JUMP_VELOCITY
	_jump_buffer = 0.0
	_coyote = 0.0
	_stretch()
	_dust_burst()
	Audio.play_sfx("jump", randf_range(0.97, 1.05))


func _do_double_jump() -> void:
	velocity.y = DOUBLE_JUMP_VELOCITY
	_jump_buffer = 0.0
	_air_jumps -= 1
	Audio.play_sfx("double_jump", randf_range(0.97, 1.05))
	_stretch()
	var tw := create_tween()
	_flip.rotation.x = 0.0
	tw.tween_property(_flip, "rotation:x", -TAU, 0.45).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_callback(func(): _flip.rotation.x = 0.0)


func _on_landed() -> void:
	if _squash_tween:
		_squash_tween.kill()
	_model.scale = Vector3(1.22, 0.78, 1.22)
	_squash_tween = create_tween()
	_squash_tween.tween_property(_model, "scale", Vector3.ONE, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_dust_burst()
	Audio.play_sfx("land", 1.0, -6.0)


func _stretch() -> void:
	if _squash_tween:
		_squash_tween.kill()
	_model.scale = Vector3(0.82, 1.22, 0.82)
	_squash_tween = create_tween()
	_squash_tween.tween_property(_model, "scale", Vector3.ONE, 0.25).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)


func _dust_burst() -> void:
	_dust.global_position = global_position + Vector3(0, 0.1, 0)
	_dust.restart()
	_dust.emitting = true


func apply_knockback(v: Vector3) -> void:
	velocity = v
	_knock_time = 0.35
	_coyote = 0.0


func set_model_visible(v: bool) -> void:
	_model.visible = v
	_blob.visible = v and _ray.is_colliding()


func is_model_visible() -> bool:
	return _model.visible


func teleport(pos: Vector3) -> void:
	global_position = pos
	velocity = Vector3.ZERO
	_knock_time = 0.0
	_coyote = 0.0
	_jump_buffer = 0.0
	_air_jumps = 1
	_flip.rotation.x = 0.0
	_model.scale = Vector3.ONE
	_model.rotation.y = 0.0
	_was_on_floor = true


func _update_blob() -> void:
	if _ray.is_colliding():
		_blob.visible = true
		var p := _ray.get_collision_point()
		_blob.global_position = p + Vector3(0, 0.03, 0)
		var h := global_position.y - p.y
		var s := clampf(1.0 - h * 0.05, 0.35, 1.0)
		_blob.scale = Vector3(s, 1.0, s)
	else:
		_blob.visible = false


# ------------------------------------------------------------------ animation
func _process(delta: float) -> void:
	var on_floor := is_on_floor()
	var hspeed := Vector2(velocity.x, velocity.z).length()
	var ratio := clampf(hspeed / SPEED, 0.0, 1.0)
	var k := 1.0 - exp(-18.0 * delta)
	if celebrating:
		_arm_l.rotation.x = lerpf(_arm_l.rotation.x, 2.9, k)
		_arm_r.rotation.x = lerpf(_arm_r.rotation.x, 2.9, k)
		_leg_l.rotation.x = lerpf(_leg_l.rotation.x, -0.3, k)
		_leg_r.rotation.x = lerpf(_leg_r.rotation.x, 0.3, k)
		_model.rotation.y += delta * 5.0
	elif on_floor:
		if ratio > 0.12:
			_run_phase += delta * (7.0 + 9.0 * ratio)
			var s := sin(_run_phase)
			_leg_l.rotation.x = s * 0.95 * ratio
			_leg_r.rotation.x = -s * 0.95 * ratio
			_arm_l.rotation.x = -s * 0.85 * ratio
			_arm_r.rotation.x = s * 0.85 * ratio
			_torso.position.y = 0.78 + absf(cos(_run_phase)) * 0.07 * ratio
			_torso.rotation.x = lerpf(_torso.rotation.x, -0.2 * ratio, k)
			var half := int(floor(_run_phase / PI))
			if half != _last_step_half:
				_last_step_half = half
				Audio.play_sfx("step", randf_range(0.9, 1.15), -14.0)
		else:
			_idle_t += delta
			_leg_l.rotation.x = lerpf(_leg_l.rotation.x, 0.0, k)
			_leg_r.rotation.x = lerpf(_leg_r.rotation.x, 0.0, k)
			_arm_l.rotation.x = lerpf(_arm_l.rotation.x, sin(_idle_t * 2.0) * 0.08, k)
			_arm_r.rotation.x = lerpf(_arm_r.rotation.x, -sin(_idle_t * 2.0) * 0.08, k)
			_torso.rotation.x = lerpf(_torso.rotation.x, 0.0, k)
			_torso.position.y = lerpf(_torso.position.y, 0.78 + sin(_idle_t * 2.0) * 0.012, k)
	else:
		var rising := velocity.y > 0.0
		_arm_l.rotation.x = lerpf(_arm_l.rotation.x, 2.5 if rising else 1.3, k)
		_arm_r.rotation.x = lerpf(_arm_r.rotation.x, 2.5 if rising else 1.3, k)
		_leg_l.rotation.x = lerpf(_leg_l.rotation.x, 0.7 if rising else 0.25, k)
		_leg_r.rotation.x = lerpf(_leg_r.rotation.x, -0.5 if rising else -0.2, k)
		_torso.rotation.x = lerpf(_torso.rotation.x, -0.1, k)
