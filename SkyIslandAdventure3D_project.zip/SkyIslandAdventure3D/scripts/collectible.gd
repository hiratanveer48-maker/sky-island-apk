class_name Collectible
extends Area3D
## A spinning gold coin (10 points) or cyan diamond (100 points).

signal collected(item: Collectible)

var is_gem := false

static var _coin_mesh: CylinderMesh
static var _gem_mesh: SphereMesh

var _pivot: Node3D
var _t := randf() * 10.0
var _taken := false


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 0.8
	cs.shape = sh
	add_child(cs)

	_pivot = Node3D.new()
	add_child(_pivot)
	var mi := MeshInstance3D.new()
	if is_gem:
		if _gem_mesh == null:
			_gem_mesh = SphereMesh.new()
			_gem_mesh.radius = 0.36
			_gem_mesh.height = 0.72
			_gem_mesh.radial_segments = 4
			_gem_mesh.rings = 2
		mi.mesh = _gem_mesh
		mi.material_override = Util.mat(Color("3fd8ff"), 0.25, 0.8)
		mi.scale = Vector3(1.0, 1.45, 1.0)
	else:
		if _coin_mesh == null:
			_coin_mesh = CylinderMesh.new()
			_coin_mesh.top_radius = 0.4
			_coin_mesh.bottom_radius = 0.4
			_coin_mesh.height = 0.1
			_coin_mesh.radial_segments = 16
			_coin_mesh.rings = 1
		mi.mesh = _coin_mesh
		mi.material_override = Util.mat(Color("ffc926"), 0.35, 0.55)
		mi.rotation_degrees.z = 90.0
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_pivot.add_child(mi)
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	_t += delta
	if _taken:
		return
	_pivot.rotation.y += (2.2 if is_gem else 3.2) * delta
	_pivot.position.y = sin(_t * 2.6) * 0.12


func _on_body_entered(body: Node3D) -> void:
	if _taken or not (body is Player):
		return
	_taken = true
	collected.emit(self)
	set_deferred("monitoring", false)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(_pivot, "scale", Vector3.ONE * 1.7, 0.16)
	tw.tween_property(_pivot, "position:y", _pivot.position.y + 0.9, 0.16)
	tw.chain().tween_property(_pivot, "scale", Vector3.ZERO, 0.08)
	tw.chain().tween_callback(queue_free)
