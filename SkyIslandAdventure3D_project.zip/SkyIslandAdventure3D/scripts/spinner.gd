class_name Spinner
extends AnimatableBody3D
## Rotating sweeper bar. Jump over it (or time your run) - it will push you
## towards the island edge if it hits you.

var speed := 1.5


func setup(length: float, spin_speed: float) -> void:
	sync_to_physics = true
	collision_layer = 1
	collision_mask = 0
	speed = spin_speed
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(length, 0.7, 0.5)
	cs.shape = sh
	cs.position = Vector3(0, 0.35, 0)
	add_child(cs)

	var red := Util.mat(Color("e8453c"), 0.5, 0.15)
	var white := Util.mat(Color("f5f5f5"), 0.5)
	var stripes := 6
	var seg := length / stripes
	for i in stripes:
		var mat: Material = red if i % 2 == 0 else white
		Util.add_box(self, Vector3(seg, 0.7, 0.5), Vector3(-length * 0.5 + seg * (i + 0.5), 0.35, 0), mat)
	Util.add_cyl(self, 0.55, 0.65, 0.95, Vector3(0, 0.47, 0), Util.mat(Color("3a3f55")), 12)
	Util.add_sphere(self, 0.3, Vector3(0, 1.0, 0), Util.mat(Color("ffd23f"), 0.4, 0.6), Vector3.ONE, 8)


func _physics_process(delta: float) -> void:
	rotation.y += speed * delta
