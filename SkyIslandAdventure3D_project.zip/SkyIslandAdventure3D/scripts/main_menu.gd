extends Control
## Main menu: logo, Play, Level Select, Settings, Quit.

const GAME_SCENE := "res://scenes/game.tscn"
const LOGO_PATH := "res://branding/game_logo.png"   # replace this file with your own logo

var _overlay: Control
var _holder: CenterContainer
var _high_lbl: Label


func _ready() -> void:
	theme = UIKit.make_theme()
	get_tree().paused = false
	add_child(MenuBackground.new())
	_build_main()
	_build_overlay()
	Audio.play_music("menu_theme")


func _build_main() -> void:
	var center := CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	center.add_child(vb)

	var logo := TextureRect.new()
	logo.texture = load(LOGO_PATH)
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	logo.custom_minimum_size = Vector2(560, 300)
	logo.pivot_offset = Vector2(280, 150)
	vb.add_child(logo)
	var tw := create_tween().set_loops()
	tw.tween_property(logo, "rotation_degrees", 1.6, 2.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(logo, "rotation_degrees", -1.6, 2.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	_high_lbl = UIKit.label("HIGH SCORE  %d" % GameState.high_score, 32, UIKit.C_GOLD)
	vb.add_child(_high_lbl)

	var play := UIKit.button("PLAY", _on_play, Vector2(440, 96), 50)
	vb.add_child(play)

	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 14)
	row.add_child(UIKit.button("Levels", _show_levels, Vector2(200, 70), 28))
	row.add_child(UIKit.button("Settings", _show_settings, Vector2(200, 70), 28))
	row.add_child(UIKit.button("Quit", _on_quit, Vector2(200, 70), 28))
	vb.add_child(row)

	var ver := UIKit.label("v1.0", 22, Color(1, 1, 1, 0.8), HORIZONTAL_ALIGNMENT_RIGHT)
	add_child(ver)
	ver.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	ver.offset_left = -120
	ver.offset_top = -44
	ver.offset_right = -18
	ver.offset_bottom = -10


func _build_overlay() -> void:
	_overlay = Control.new()
	_overlay.visible = false
	_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_overlay)
	_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.05, 0.14, 0.6)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_overlay.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_holder = CenterContainer.new()
	_overlay.add_child(_holder)
	_holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _open(content: Control) -> void:
	for c in _holder.get_children():
		_holder.remove_child(c)
		c.queue_free()
	_holder.add_child(content)
	_overlay.visible = true


func _close_overlay() -> void:
	_overlay.visible = false
	for c in _holder.get_children():
		_holder.remove_child(c)
		c.queue_free()
	_high_lbl.text = "HIGH SCORE  %d" % GameState.high_score


# ------------------------------------------------------------------ actions
func _on_play() -> void:
	_start_level(GameState.unlocked_level)


func _start_level(n: int) -> void:
	GameState.start_level(n, true)
	get_tree().change_scene_to_file(GAME_SCENE)


func _on_quit() -> void:
	GameState.save_game()
	get_tree().quit()


func _show_settings() -> void:
	var sp := SettingsPanel.new()
	sp.allow_reset = true
	sp.closed.connect(_close_overlay)
	_open(sp)


func _show_levels() -> void:
	var pc := PanelContainer.new()
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 16)
	pc.add_child(vb)
	vb.add_child(UIKit.label("SELECT LEVEL", 50, UIKit.C_GOLD))

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(row)
	for i in range(1, GameState.MAX_LEVEL + 1):
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 8)
		var unlocked := i <= GameState.unlocked_level
		var name_lbl := UIKit.label(GameState.LEVEL_NAMES[i - 1], 22, Color.WHITE)
		name_lbl.custom_minimum_size = Vector2(190, 56)
		name_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		name_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		col.add_child(name_lbl)
		var lvl := i
		var b := UIKit.button(str(i) if unlocked else "?", func() -> void: _start_level(lvl), Vector2(190, 130), 64)
		b.disabled = not unlocked
		col.add_child(b)
		var stars := HBoxContainer.new()
		stars.alignment = BoxContainer.ALIGNMENT_CENTER
		for s in 3:
			var ic := HudIcon.new(HudIcon.Kind.STAR, 40.0)
			ic.set_lit(s < int(GameState.best_stars.get(i, 0)))
			stars.add_child(ic)
		col.add_child(stars)
		var best := int(GameState.best_scores.get(i, 0))
		col.add_child(UIKit.label("Best %d" % best if best > 0 else "-", 24, Color(1, 1, 1, 0.85)))
		row.add_child(col)

	vb.add_child(UIKit.button("Back", _close_overlay, Vector2(0, 72)))
	_open(pc)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if _overlay != null and _overlay.visible:
			_close_overlay()
		else:
			_on_quit()
