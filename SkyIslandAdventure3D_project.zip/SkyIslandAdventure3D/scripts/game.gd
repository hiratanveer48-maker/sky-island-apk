extends Node3D
## Level controller: builds the level, runs score / lives / checkpoints,
## pause, game over and the level-complete flow.

enum State { PLAYING, PAUSED, RESPAWNING, COMPLETE, OVER }

const MENU_SCENE := "res://scenes/main_menu.tscn"
const START_LIVES := 3
const COINS_PER_LIFE := 50

@onready var level_root: Node3D = $LevelRoot
@onready var player: Player = $Player
@onready var cam: CameraRig = $CameraRig
@onready var hud: HudLayer = $HUD
@onready var sun: DirectionalLight3D = $Sun

var level := 1
var theme: Dictionary = {}
var builder: LevelBuilder
var state: State = State.PLAYING
var lives := START_LIVES
var coins := 0
var gems := 0
var coin_total := 0
var gem_total := 0
var level_score := 0
var run_start_score := 0
var elapsed := 0.0
var checkpoint_pos := Vector3.ZERO
var invuln := 0.0

var _respawn_timer := 0.0
var _stars_node: Node3D


func _ready() -> void:
	level = GameState.current_level
	theme = LevelsData.get_theme(level)
	run_start_score = GameState.run_score

	_setup_environment()
	builder = LevelBuilder.new()
	builder.build(level, self, level_root)
	coin_total = builder.coin_total
	gem_total = builder.gem_total

	player.camera_rig = cam
	cam.target = player
	checkpoint_pos = builder.spawn_pos
	player.teleport(checkpoint_pos)
	cam.yaw = 0.0
	cam.snap()

	hud.setup(level, GameState.LEVEL_NAMES[level - 1])
	hud.pause_toggled.connect(toggle_pause)
	hud.resume_requested.connect(_resume)
	hud.restart_requested.connect(_restart)
	hud.menu_requested.connect(_to_menu)
	hud.next_requested.connect(_next_level)
	_refresh_hud()
	hud.toast("LEVEL %d  -  %s" % [level, GameState.LEVEL_NAMES[level - 1]], Color.WHITE, 2.2)

	Audio.play_music(theme.get("music", "adventure_theme"))


func _setup_environment() -> void:
	var env := Environment.new()
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = theme.sky_top
	sm.sky_horizon_color = theme.sky_horizon
	# the camera looks down a lot, so the "ground" half of the sky must stay bright
	sm.sky_curve = 0.25
	sm.ground_curve = 0.12
	sm.ground_horizon_color = theme.sky_horizon
	sm.ground_bottom_color = Color(theme.sky_top).lerp(Color(theme.sky_horizon), 0.35)
	sm.sun_angle_max = 0.0
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = theme.ambient
	env.ambient_light_energy = 0.95
	env.fog_enabled = true
	env.fog_light_color = theme.fog
	env.fog_density = 0.0028
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun.rotation_degrees = Vector3(-52.0, -38.0, 0.0)
	sun.light_color = theme.sun
	sun.light_energy = 1.1
	sun.shadow_enabled = GameState.shadows_enabled()
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 45.0
	sun.shadow_bias = 0.08
	if theme.get("night", false):
		_add_stars()


func _add_stars() -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	var m := SphereMesh.new()
	m.radius = 0.4
	m.height = 0.8
	m.radial_segments = 4
	m.rings = 2
	mm.mesh = m
	mm.instance_count = 150
	var rng := RandomNumberGenerator.new()
	rng.seed = 99
	for i in 150:
		var dir := Vector3(rng.randf_range(-1, 1), rng.randf_range(-0.6, 1), rng.randf_range(-1, 1)).normalized()
		var s := rng.randf_range(0.5, 1.5)
		mm.set_instance_transform(i, Transform3D(Basis.IDENTITY.scaled(Vector3.ONE * s), dir * 150.0))
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(1.0, 1.0, 0.9)
	mat.disable_fog = true
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.top_level = true
	add_child(mi)
	_stars_node = mi


# ------------------------------------------------------------------ loop
func _physics_process(delta: float) -> void:
	match state:
		State.PLAYING:
			elapsed += delta
			if invuln > 0.0:
				invuln -= delta
				player.set_model_visible(invuln <= 0.0 or int(invuln * 12.0) % 2 == 0)
			elif not player.is_model_visible():
				player.set_model_visible(true)
			if player.global_position.y < builder.kill_y:
				_on_fell()
		State.RESPAWNING:
			_respawn_timer -= delta
			if _respawn_timer <= 0.0:
				_do_respawn()


func _process(_delta: float) -> void:
	if _stars_node != null:
		_stars_node.global_position = cam.global_position


# ------------------------------------------------------------------ callbacks from level objects
func on_collected(item: Collectible) -> void:
	if state != State.PLAYING:
		return
	if item.is_gem:
		gems += 1
		level_score += 100
		Audio.play_sfx("diamond")
		GameState.vibrate(30)
	else:
		coins += 1
		level_score += 10
		Audio.play_sfx("coin", randf_range(0.96, 1.08))
		if coins % COINS_PER_LIFE == 0:
			lives += 1
			Audio.play_sfx("extra_life")
			hud.toast("EXTRA LIFE!", Color("7dff9b"))
	_refresh_hud()


func on_checkpoint(cp: Checkpoint) -> void:
	checkpoint_pos = cp.global_position + Vector3(0, 0.7, -1.6)
	Audio.play_sfx("checkpoint")
	hud.toast("CHECKPOINT!", Color("7dff9b"))
	GameState.vibrate(40)


func on_hazard(trap: Node3D) -> void:
	if state != State.PLAYING or invuln > 0.0:
		return
	lives -= 1
	invuln = 1.6
	Audio.play_sfx("hurt")
	GameState.vibrate(140)
	cam.shake(0.22)
	hud.flash(Color(1, 0.15, 0.15, 0.4))
	var away := player.global_position - trap.global_position
	away.y = 0.0
	away = away.normalized() if away.length() > 0.05 else Vector3(0, 0, 1)
	player.apply_knockback(away * 7.0 + Vector3(0, 8.5, 0))
	_refresh_hud()
	if lives <= 0:
		_game_over()


func on_chest() -> void:
	if state != State.PLAYING:
		return
	state = State.COMPLETE
	player.controls_enabled = false
	player.celebrating = true
	player.set_model_visible(true)
	Audio.play_sfx("chest")
	GameState.vibrate(90)
	hud.set_controls_active(false)
	hud.toast("TREASURE FOUND!", UIKit.C_GOLD, 1.4)
	await get_tree().create_timer(1.5, false).timeout
	_show_complete()


# ------------------------------------------------------------------ lives / respawn
func _on_fell() -> void:
	lives -= 1
	Audio.play_sfx("fall")
	GameState.vibrate(120)
	hud.flash(Color(0, 0, 0, 0.55))
	_refresh_hud()
	if lives <= 0:
		_game_over()
		return
	state = State.RESPAWNING
	_respawn_timer = 0.7
	player.controls_enabled = false
	player.set_physics_process(false)
	player.set_model_visible(false)


func _do_respawn() -> void:
	player.set_physics_process(true)
	player.controls_enabled = true
	player.teleport(checkpoint_pos)
	player.set_model_visible(true)
	cam.yaw = 0.0
	cam.snap()
	invuln = 1.5
	state = State.PLAYING


func _game_over() -> void:
	state = State.OVER
	player.controls_enabled = false
	player.set_physics_process(false)
	var final_score := run_start_score + level_score
	GameState.note_run_end(final_score)
	hud.set_controls_active(false)
	await get_tree().create_timer(0.8, false).timeout
	Audio.play_sfx("hurt")
	hud.show_game_over(final_score)


func _show_complete() -> void:
	var chest_bonus := 500
	var life_bonus := lives * 100
	var par: int = LevelsData.PAR_TIMES[level - 1]
	var time_bonus := maxi(0, int((float(par) - elapsed) * 5.0))
	var level_total := level_score + chest_bonus + life_bonus + time_bonus
	var coin_ratio := float(coins) / maxf(float(coin_total), 1.0)
	var stars := 1
	if coin_ratio >= 0.7:
		stars += 1
	if gems >= gem_total:
		stars += 1
	var prev_high := GameState.high_score
	GameState.complete_level(level, level_total, stars, coins)
	Audio.play_sfx("win")
	hud.set_score(GameState.run_score)
	hud.show_level_complete({
		"stars": stars, "coins": coins, "coin_total": coin_total, "gems": gems, "gem_total": gem_total,
		"time": elapsed,
		"rows": [["Coins", coins * 10], ["Diamonds", gems * 100], ["Treasure", chest_bonus],
				["Time bonus", time_bonus], ["Lives left", life_bonus]],
		"level_total": level_total, "run_total": GameState.run_score,
		"new_high": GameState.high_score > prev_high,
		"is_last": level >= GameState.MAX_LEVEL,
	})


# ------------------------------------------------------------------ pause & scene flow
func toggle_pause() -> void:
	if state == State.PLAYING:
		state = State.PAUSED
		get_tree().paused = true
		hud.show_pause()
	elif state == State.PAUSED:
		_resume()


func _resume() -> void:
	if state != State.PAUSED:
		return
	state = State.PLAYING
	get_tree().paused = false
	hud.hide_overlay()


func _restart() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func _next_level() -> void:
	GameState.start_level(level + 1, false)
	get_tree().paused = false
	get_tree().reload_current_scene()


func _to_menu() -> void:
	get_tree().paused = false
	GameState.save_game()
	get_tree().change_scene_to_file(MENU_SCENE)


func _refresh_hud() -> void:
	hud.set_coins(coins, coin_total)
	hud.set_gems(gems, gem_total)
	hud.set_lives(lives)
	hud.set_score(run_start_score + level_score)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		toggle_pause()          # Android back button
	elif what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		if state == State.PLAYING:
			toggle_pause()      # auto-pause when the app goes to the background
