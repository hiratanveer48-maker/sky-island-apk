class_name SpikeTrap
extends Area3D
## Static spikes. Touching them costs a life (the game applies knock-back and
## a short invulnerability, so repeated signals are harmless).

signal touched(trap: SpikeTrap)


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(1.7, 0.9, 1.7)
	cs.shape = sh
	cs.position = Vector3(0, 0.45, 0)
	add_child(cs)

	Util.add_box(self, Vector3(1.9, 0.14, 1.9), Vector3(0, 0.07, 0), Util.mat(Color("5a2a2a")))
	var metal := Util.mat(Color("dfe4ee"), 0.3, 0.15)
	for ix in [-0.45, 0.45]:
		for iz in [-0.45, 0.45]:
			Util.add_cyl(self, 0.0, 0.22, 0.85, Vector3(ix, 0.55, iz), metal, 6)
	Util.add_box(self, Vector3(1.95, 0.05, 1.95), Vector3(0, 0.15, 0), Util.mat(Color("ff3b30"), 0.6, 0.5))


func _physics_process(_delta: float) -> void:
	for b in get_overlapping_bodies():
		if b is Player:
			touched.emit(self)
			return
