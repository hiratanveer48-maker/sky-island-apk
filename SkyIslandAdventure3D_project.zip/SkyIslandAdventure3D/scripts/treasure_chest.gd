class_name TreasureChest
extends Area3D
## The goal of every level. Touch it to open it and finish the level.

signal opened

var is_open := false
var _lid: Node3D
var _beam: MeshInstance3D
var _gem: Node3D
var _t := 0.0


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(3.2, 2.6, 3.0)
	cs.shape = sh
	cs.position = Vector3(0, 1.2, 0)
	add_child(cs)

	var wood := Util.mat(Color("a9672a"))
	var wood_dark := Util.mat(Color("8a4f1d"))
	var gold := Util.mat(Color("ffcc2e"), 0.35, 0.5)
	# base (front of the chest faces +Z, towards the player)
	Util.add_box(self, Vector3(1.6, 0.8, 1.1), Vector3(0, 0.4, 0), wood)
	Util.add_box(self, Vector3(1.64, 0.1, 1.14), Vector3(0, 0.05, 0), wood_dark)
	for sx in [-0.62, 0.62]:
		Util.add_box(self, Vector3(0.14, 0.84, 1.16), Vector3(sx, 0.4, 0), gold)
	# lid hinged at the back
	_lid = Node3D.new()
	_lid.position = Vector3(0, 0.8, -0.55)
	add_child(_lid)
	Util.add_box(_lid, Vector3(1.6, 0.4, 1.1), Vector3(0, 0.2, 0.55), wood)
	for sx in [-0.62, 0.62]:
		Util.add_box(_lid, Vector3(0.14, 0.44, 1.16), Vector3(sx, 0.2, 0.55), gold)
	Util.add_box(self, Vector3(0.24, 0.28, 0.08), Vector3(0, 0.78, 0.58), gold)   # clasp

	# glowing beam + floating diamond make the goal easy to spot from afar
	_beam = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.7
	cm.bottom_radius = 0.9
	cm.height = 16.0
	cm.radial_segments = 12
	cm.rings = 1
	_beam.mesh = cm
	var bm := StandardMaterial3D.new()
	bm.albedo_color = Color(1.0, 0.85, 0.3, 0.16)
	bm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bm.cull_mode = BaseMaterial3D.CULL_DISABLED
	_beam.material_override = bm
	_beam.position = Vector3(0, 8.4, 0)
	_beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_beam)

	_gem = Node3D.new()
	_gem.position = Vector3(0, 2.4, 0)
	add_child(_gem)
	var gm := Util.add_sphere(_gem, 0.3, Vector3.ZERO, Util.mat(Color("ffe45c"), 0.3, 0.9), Vector3(1, 1.4, 1), 4)
	gm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	_t += delta
	if _gem and not is_open:
		_gem.rotation.y += 2.0 * delta
		_gem.position.y = 2.4 + sin(_t * 2.5) * 0.15


func _on_body_entered(body: Node3D) -> void:
	if is_open or not (body is Player):
		return
	open()


func open() -> void:
	is_open = true
	set_deferred("monitoring", false)
	var tw := create_tween()
	tw.tween_property(_lid, "rotation_degrees:x", -115.0, 0.45).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	if _gem:
		_gem.visible = false
	_burst()
	opened.emit()


func _burst() -> void:
	var p := CPUParticles3D.new()
	p.amount = 36
	p.lifetime = 1.3
	p.one_shot = true
	p.explosiveness = 1.0
	p.direction = Vector3(0, 1, 0)
	p.spread = 38.0
	p.initial_velocity_min = 5.0
	p.initial_velocity_max = 9.0
	p.gravity = Vector3(0, -12.0, 0)
	p.scale_amount_min = 0.7
	p.scale_amount_max = 1.4
	var m := BoxMesh.new()
	m.size = Vector3(0.16, 0.16, 0.16)
	p.mesh = m
	p.material_override = Util.mat(Color("ffd83a"), 0.4, 1.0, true)
	p.position = Vector3(0, 1.0, 0)
	add_child(p)
	p.emitting = true
