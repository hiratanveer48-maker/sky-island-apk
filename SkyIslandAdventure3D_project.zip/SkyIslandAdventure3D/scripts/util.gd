class_name Util
extends RefCounted
## Small helpers for building 3D geometry in code (keeps the project free of
## external model files and very light on memory - ideal for phones).

static var _mat_cache: Dictionary = {}


static func mat(color: Color, rough: float = 0.9, emission: float = 0.0, unshaded: bool = false) -> StandardMaterial3D:
	var key := "%s|%s|%s|%s" % [color.to_html(true), rough, emission, unshaded]
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	if emission > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = emission
	if unshaded:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	if color.a < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_mat_cache[key] = m
	return m


static func add_box(parent: Node, size: Vector3, pos: Vector3, material: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var m := BoxMesh.new()
	m.size = size
	mi.mesh = m
	mi.material_override = material
	mi.position = pos
	mi.rotation_degrees = rot_deg
	parent.add_child(mi)
	return mi


static func add_box_basis(parent: Node, size: Vector3, origin: Vector3, basis: Basis, material: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var m := BoxMesh.new()
	m.size = size
	mi.mesh = m
	mi.material_override = material
	mi.transform = Transform3D(basis, origin)
	parent.add_child(mi)
	return mi


static func add_cyl(parent: Node, top_r: float, bottom_r: float, h: float, pos: Vector3, material: Material, segs: int = 14) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var m := CylinderMesh.new()
	m.top_radius = top_r
	m.bottom_radius = bottom_r
	m.height = h
	m.radial_segments = segs
	m.rings = 1
	mi.mesh = m
	mi.material_override = material
	mi.position = pos
	parent.add_child(mi)
	return mi


static func add_sphere(parent: Node, r: float, pos: Vector3, material: Material, scl: Vector3 = Vector3.ONE, segs: int = 12) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var m := SphereMesh.new()
	m.radius = r
	m.height = r * 2.0
	m.radial_segments = segs
	m.rings = maxi(4, segs / 2)
	mi.mesh = m
	mi.material_override = material
	mi.position = pos
	mi.scale = scl
	parent.add_child(mi)
	return mi


static func add_capsule(parent: Node, r: float, h: float, pos: Vector3, material: Material, segs: int = 10) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var m := CapsuleMesh.new()
	m.radius = r
	m.height = h
	m.radial_segments = segs
	m.rings = 4
	mi.mesh = m
	mi.material_override = material
	mi.position = pos
	parent.add_child(mi)
	return mi


## Creates a StaticBody3D with a box collision shape. Layer 1 = world.
static func make_static_box(size: Vector3, layer: int = 1) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.collision_layer = layer
	body.collision_mask = 0
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	cs.shape = sh
	body.add_child(cs)
	return body


## Small circular texture (used for slider grabbers etc.)
static func circle_texture(diameter: int, fill: Color, border: Color, border_w: int) -> ImageTexture:
	var img := Image.create(diameter, diameter, false, Image.FORMAT_RGBA8)
	var c := Vector2(diameter / 2.0, diameter / 2.0)
	var rad := diameter / 2.0
	for y in diameter:
		for x in diameter:
			var d := Vector2(x + 0.5, y + 0.5).distance_to(c)
			var a := clampf(rad - d, 0.0, 1.0)
			if a <= 0.0:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
				continue
			var col := fill
			if d > rad - border_w:
				col = border
			col.a *= a
			img.set_pixel(x, y, col)
	return ImageTexture.create_from_image(img)
