class_name HudIcon
extends Control
## Tiny vector icons (coin, diamond, heart, star) drawn in code - no image files.

enum Kind { COIN, GEM, HEART, STAR }

var kind: Kind = Kind.COIN
var lit := true


func _init(k: Kind = Kind.COIN, px: float = 40.0) -> void:
	kind = k
	custom_minimum_size = Vector2(px, px)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func set_lit(on: bool) -> void:
	lit = on
	queue_redraw()


func _draw() -> void:
	var s := minf(size.x, size.y)
	var c := Vector2(s, s) * 0.5
	match kind:
		Kind.COIN:
			draw_circle(c, s * 0.47, Color("c98a0c"))
			draw_circle(c, s * 0.40, Color("ffcf2e"))
			draw_arc(c, s * 0.26, 0.0, TAU, 20, Color("e5a516"), maxf(2.0, s * 0.06))
			draw_circle(c + Vector2(-s * 0.1, -s * 0.1), s * 0.06, Color(1, 1, 1, 0.7))
		Kind.GEM:
			var top := PackedVector2Array([Vector2(s * 0.5, s * 0.05), Vector2(s * 0.85, s * 0.38), Vector2(s * 0.5, s * 0.38), Vector2(s * 0.15, s * 0.38)])
			draw_colored_polygon(PackedVector2Array([Vector2(s * 0.5, s * 0.05), Vector2(s * 0.88, s * 0.38), Vector2(s * 0.5, s * 0.95), Vector2(s * 0.12, s * 0.38)]), Color("38c9f5"))
			draw_colored_polygon(PackedVector2Array([Vector2(s * 0.5, s * 0.05), Vector2(s * 0.88, s * 0.38), Vector2(s * 0.5, s * 0.38)]), Color("a8f0ff"))
			draw_colored_polygon(PackedVector2Array([Vector2(s * 0.5, s * 0.38), Vector2(s * 0.88, s * 0.38), Vector2(s * 0.5, s * 0.95)]), Color("1f9fd8"))
			draw_colored_polygon(PackedVector2Array([Vector2(s * 0.5, s * 0.05), Vector2(s * 0.12, s * 0.38), Vector2(s * 0.5, s * 0.38)]), Color("6fe2ff"))
			top.clear()
		Kind.HEART:
			var red := Color("ff4560") if lit else Color(1, 1, 1, 0.25)
			draw_circle(Vector2(s * 0.31, s * 0.36), s * 0.23, red)
			draw_circle(Vector2(s * 0.69, s * 0.36), s * 0.23, red)
			draw_colored_polygon(PackedVector2Array([Vector2(s * 0.09, s * 0.43), Vector2(s * 0.91, s * 0.43), Vector2(s * 0.5, s * 0.92)]), red)
			if lit:
				draw_circle(Vector2(s * 0.27, s * 0.3), s * 0.06, Color(1, 1, 1, 0.65))
		Kind.STAR:
			var col := Color("ffd23f") if lit else Color(0.0, 0.0, 0.0, 0.35)
			var pts := PackedVector2Array()
			for i in 10:
				var a := -PI * 0.5 + float(i) * PI / 5.0
				var rr := s * 0.48 if i % 2 == 0 else s * 0.21
				pts.append(c + Vector2(cos(a), sin(a)) * rr + Vector2(0, s * 0.03))
			draw_colored_polygon(pts, col)
			if lit:
				draw_polyline(pts + PackedVector2Array([pts[0]]), Color("c98a0c"), maxf(2.0, s * 0.05))
