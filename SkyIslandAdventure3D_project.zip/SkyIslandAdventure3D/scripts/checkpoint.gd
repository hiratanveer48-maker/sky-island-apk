class_name Checkpoint
extends Area3D
## Flag pole. Touch it once to set your respawn point.

signal reached(cp: Checkpoint)

var active := false
var _flag: MeshInstance3D


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(3.6, 4.0, 3.6)
	cs.shape = sh
	cs.position = Vector3(0, 1.8, 0)
	add_child(cs)

	var stone := Util.mat(Color("8d96a8"))
	var metal := Util.mat(Color("e8ecf4"), 0.4)
	Util.add_cyl(self, 0.38, 0.5, 0.22, Vector3(0, 0.11, 0), stone, 10)
	Util.add_cyl(self, 0.06, 0.06, 3.1, Vector3(0, 1.65, 0), metal, 6)
	Util.add_sphere(self, 0.13, Vector3(0, 3.25, 0), Util.mat(Color("ffcf3a"), 0.4, 0.5), Vector3.ONE, 8)
	_flag = Util.add_box(self, Vector3(1.1, 0.7, 0.05), Vector3(0.58, 2.75, 0), Util.mat(Color("ff4b4b"), 0.7, 0.2))
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node3D) -> void:
	if active or not (body is Player):
		return
	activate()


func activate() -> void:
	active = true
	_flag.material_override = Util.mat(Color("3ee06a"), 0.6, 0.7)
	var tw := create_tween()
	_flag.scale = Vector3(0.2, 1.0, 1.0)
	tw.tween_property(_flag, "scale", Vector3.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	reached.emit(self)
