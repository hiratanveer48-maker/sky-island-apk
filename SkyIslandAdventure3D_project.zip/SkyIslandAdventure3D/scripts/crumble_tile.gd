class_name CrumbleTile
extends StaticBody3D
## A tile that shakes for a moment after you step on it, then falls away.
## It comes back after a few seconds so retries are possible.

const SHAKE_TIME := 0.5
const RESPAWN_TIME := 3.2

var _state := 0          # 0 = solid, 1 = shaking, 2 = fallen
var _timer := 0.0
var _shape: CollisionShape3D
var _mesh: Node3D
var _fall_speed := 0.0


func setup(size: Vector3, color: Color) -> void:
	collision_layer = 1
	collision_mask = 0
	_shape = CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	_shape.shape = sh
	add_child(_shape)
	_mesh = Node3D.new()
	add_child(_mesh)
	Util.add_box(_mesh, size, Vector3.ZERO, Util.mat(color))
	Util.add_box(_mesh, Vector3(size.x * 0.94, 0.04, size.z * 0.9), Vector3(0, size.y * 0.5, 0), Util.mat(color.lightened(0.18)))
	# cracks (purely visual hint that this tile is fragile)
	Util.add_box(_mesh, Vector3(size.x * 0.7, 0.02, 0.05), Vector3(0, size.y * 0.5 + 0.02, size.z * 0.12), Util.mat(color.darkened(0.55)), Vector3(0, 12, 0))

	var trig := Area3D.new()
	trig.collision_layer = 0
	trig.collision_mask = 2
	var tcs := CollisionShape3D.new()
	var tsh := BoxShape3D.new()
	tsh.size = Vector3(size.x * 0.96, 0.6, size.z * 0.96)
	tcs.shape = tsh
	tcs.position = Vector3(0, size.y * 0.5 + 0.25, 0)
	trig.add_child(tcs)
	add_child(trig)
	trig.body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node3D) -> void:
	if _state == 0 and body is Player:
		_state = 1
		_timer = SHAKE_TIME


func _process(delta: float) -> void:
	match _state:
		1:
			_timer -= delta
			_mesh.position.x = randf_range(-0.05, 0.05)
			_mesh.position.z = randf_range(-0.03, 0.03)
			if _timer <= 0.0:
				_state = 2
				_timer = RESPAWN_TIME
				_fall_speed = 0.0
				_mesh.position = Vector3.ZERO
				_shape.set_deferred("disabled", true)
		2:
			_timer -= delta
			_fall_speed += 30.0 * delta
			_mesh.position.y -= _fall_speed * delta
			_mesh.rotation.z += delta * 1.5
			_mesh.visible = _timer > RESPAWN_TIME - 1.4
			if _timer <= 0.0:
				_state = 0
				_mesh.position = Vector3.ZERO
				_mesh.rotation = Vector3.ZERO
				_mesh.visible = true
				_shape.set_deferred("disabled", false)
