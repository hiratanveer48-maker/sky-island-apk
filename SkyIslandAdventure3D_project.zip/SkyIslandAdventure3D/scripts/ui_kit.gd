class_name UIKit
extends RefCounted
## Shared look & feel for all menus and the HUD (one Theme built in code).

const C_PANEL := Color(0.07, 0.13, 0.27, 0.96)
const C_BORDER := Color("5fb3ff")
const C_OUTLINE := Color("10285a")
const C_GOLD := Color("ffd23f")
const C_ORANGE := Color("ffa41b")

static var _theme: Theme


static func box(bg: Color, border: Color, radius: int = 22, border_w: int = 4, bottom_extra: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(border_w)
	s.border_width_bottom = border_w + bottom_extra
	s.set_corner_radius_all(radius)
	s.anti_aliasing = true
	return s


static func make_theme() -> Theme:
	if _theme != null:
		return _theme
	var th := Theme.new()
	th.default_font_size = 30

	# buttons
	var normal := box(C_ORANGE, Color("b86500"), 22, 3, 7)
	var hover := box(Color("ffb64a"), Color("b86500"), 22, 3, 7)
	var pressed := box(Color("e18400"), Color("8f4d00"), 22, 3, 2)
	var disabled := box(Color("7e879a"), Color("535a6b"), 22, 3, 5)
	for s in [normal, hover, pressed, disabled]:
		s.content_margin_left = 26
		s.content_margin_right = 26
		s.content_margin_top = 10
		s.content_margin_bottom = 10
	th.set_stylebox("normal", "Button", normal)
	th.set_stylebox("hover", "Button", hover)
	th.set_stylebox("pressed", "Button", pressed)
	th.set_stylebox("disabled", "Button", disabled)
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	th.set_font_size("font_size", "Button", 34)
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
		th.set_color(c, "Button", Color.WHITE)
	th.set_color("font_disabled_color", "Button", Color(1, 1, 1, 0.6))
	th.set_color("font_outline_color", "Button", Color("7a3f00"))
	th.set_constant("outline_size", "Button", 5)

	# labels
	th.set_color("font_color", "Label", Color.WHITE)
	th.set_color("font_outline_color", "Label", C_OUTLINE)
	th.set_constant("outline_size", "Label", 6)

	# panels
	var panel := box(C_PANEL, C_BORDER, 30, 5)
	panel.set_content_margin_all(30)
	th.set_stylebox("panel", "PanelContainer", panel)
	th.add_type("ChipPanel")
	th.set_type_variation("ChipPanel", "PanelContainer")
	var chip := box(Color(0.04, 0.09, 0.2, 0.62), Color(1, 1, 1, 0.25), 20, 2)
	chip.content_margin_left = 12
	chip.content_margin_right = 16
	chip.content_margin_top = 4
	chip.content_margin_bottom = 4
	th.set_stylebox("panel", "ChipPanel", chip)

	# sliders
	var track := box(Color(1, 1, 1, 0.22), Color(0, 0, 0, 0), 8, 0)
	track.content_margin_top = 8
	track.content_margin_bottom = 8
	var fill := box(C_GOLD, Color(0, 0, 0, 0), 8, 0)
	fill.content_margin_top = 8
	fill.content_margin_bottom = 8
	th.set_stylebox("slider", "HSlider", track)
	th.set_stylebox("grabber_area", "HSlider", fill)
	th.set_stylebox("grabber_area_highlight", "HSlider", fill)
	var grab := Util.circle_texture(48, Color.WHITE, C_ORANGE, 8)
	th.set_icon("grabber", "HSlider", grab)
	th.set_icon("grabber_highlight", "HSlider", grab)
	th.set_icon("grabber_disabled", "HSlider", grab)
	_theme = th
	return th


static func label(text: String, size: int = 30, color: Color = Color.WHITE, align: int = HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = align as HorizontalAlignment
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


static func button(text: String, on_press: Callable, min_size: Vector2 = Vector2(300, 78), font_size: int = 34) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", font_size)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(func() -> void:
		Audio.play_sfx("click")
		on_press.call())
	return b


static func format_time(seconds: float) -> String:
	var s := int(seconds)
	return "%d:%02d" % [s / 60, s % 60]
